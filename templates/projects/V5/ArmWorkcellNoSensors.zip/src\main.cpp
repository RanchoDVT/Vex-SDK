/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Tue Mar 16 2021                                           */
/*    Description:  Arm Workcell - No Sensors                                 */
/*                                                                            */
/*    This example will help you get started with the V5                      */
/*    Workcell without sensors                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// RoboticArm1          RoboticArm    1, 2, 3, 4, 1, 2, 3, 4
// EStop                bumper        E               
// Magnet5              electromagnet 5               
// EntryMotor           motor         7               
// TransportMotor       motor         8               
// ExitMotor            motor         9               
// DiverterMotor        motor         10              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// Function to run when the emergency stop button is pressed
void onEStopPressed() {
  RoboticArm1.emergencyStop();
}

// Task function to constantly display the arm position and sensor values on the V5 Brain's screen
int positionSensorDisplay() {
  Brain.Screen.setFont(mono60);
  while (true) {
    Brain.Screen.clearScreen();

    // Display the X position on row 1
    Brain.Screen.setCursor(1, 1);
    Brain.Screen.print("X: %0.3f", RoboticArm1.getAxisPosition(xaxis));

    // Display the Y position on row 2
    Brain.Screen.newLine();
    Brain.Screen.print("Y: %0.3f", RoboticArm1.getAxisPosition(yaxis));

    // Display the Z position on row 3
    Brain.Screen.newLine();
    Brain.Screen.print("Z: %0.3f", RoboticArm1.getAxisPosition(zaxis));
    wait(0.2, seconds);
  }
  return 0;
}


int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
  // register emergency stop event handler
  EStop.pressed(onEStopPressed);

  // short wait to make sure the emergency stop event is fully registered
  wait(15, msec);

  // start the position and sensor value display task
  vex::task positionSensorDisplayTask(positionSensorDisplay);

  RoboticArm1.setMasteringValues(0.0, 0.0, 0.0, 0.0);
  RoboticArm1.setToolTipOffset(-0.7, 0.0, -1.0);
  Magnet5.setPower(100.0);
  EntryMotor.setVelocity(70.0, percent);
  TransportMotor.setVelocity(15.0, percent);
  ExitMotor.setVelocity(50.0, percent);
  DiverterMotor.setVelocity(30.0, percent);
}
