/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Reading Angles                                            */
/*                                                                            */
/*    This program stops the Arm motor from breaking by limiting the          */
/*    motion with the potentiometer.                                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// PotentiometerH       pot           H               
// ArmMotor             motor         8               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  ArmMotor.spin(forward);
  ArmMotor.setVelocity(20, percent);
  while (!(PotentiometerH.angle() > 30)) {
    Brain.Screen.clearScreen();
    Brain.Screen.print("%.2f", PotentiometerH.angle(degrees));
    Brain.Screen.setCursor(1, 1);
    wait(30, msec);
  }
  ArmMotor.stop();
}
