/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Tue Mar 30 2021                                           */
/*    Description:  Digital Out Sensing                                       */
/*                  This program will show how to control another             */
/*                  device using the Digital Out device                       */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    1, 10           
// DigitalOutA          digital_out   A               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
  while (true) {
    // Setting the Digital Out to true will send a High signal to the other device
    Brain.Screen.clearLine(1);
    Brain.Screen.setCursor(Brain.Screen.row(), 1);
    Brain.Screen.setCursor(1, 1);
    Brain.Screen.print("Output - High");
    DigitalOutA.set(true);
    wait(1.0, seconds);

    // Setting the Digital Out to false will send a Low signal to the other device
    Brain.Screen.clearLine(1);
    Brain.Screen.setCursor(Brain.Screen.row(), 1);
    Brain.Screen.setCursor(1, 1);
    Brain.Screen.print("Output - Low");
    DigitalOutA.set(false);
    wait(1.0, seconds);
  }

}
