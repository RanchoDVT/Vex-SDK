/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*    The program will stop the Arm Motor when the Limit Switch is pressed    */
/*    ensuring the motors don't break.                                        */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LimitSwitchA         limit         A
// ClawMotor            motor         3
// ArmMotor             motor         8
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

void whenLimitSwitchIsPressed() { ArmMotor.stop(); }

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  LimitSwitchA.pressed(whenLimitSwitchIsPressed);

  wait(1, seconds);
  ArmMotor.spin(reverse);
  
}