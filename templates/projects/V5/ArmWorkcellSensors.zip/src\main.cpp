/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Tue Mar 16 2021                                           */
/*    Description:  Arm Workcell - With Sensors                               */
/*                                                                            */
/*    This example will help you get started with the V5                      */
/*    Workcell with sensors                                                   */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// RoboticArm1          RoboticArm    1, 2, 3, 4, 1, 2, 3, 4
// EStop                bumper        E               
// Magnet5              electromagnet 5               
// EntryMotor           motor         7               
// TransportMotor       motor         8               
// ExitMotor            motor         9               
// DiverterMotor        motor         10              
// Optical6             optical       6               
// Load                 line          F               
// Pickup               line          G               
// Exit                 line          H               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// Function to run when the emergency stop button is pressed
void onEStopPressed() {
  RoboticArm1.emergencyStop();
}

// Task function to constantly display the arm position and sensor values on the brain screen
int positionSensorDisplay() {
  while (true) {
    Brain.Screen.clearScreen();

    // Display the X position on row 1
    Brain.Screen.setCursor(1, 1);
    Brain.Screen.print("Arm X: %0.3f", RoboticArm1.getAxisPosition(xaxis));

    // Display the Y position on row 2
    Brain.Screen.newLine();
    Brain.Screen.print("Arm Y: %0.3f", RoboticArm1.getAxisPosition(yaxis));

    // Display the Z position on row 3
    Brain.Screen.newLine();
    Brain.Screen.print("Arm Z: %0.3f", RoboticArm1.getAxisPosition(zaxis));

    // Display if a disk is detected on row 4
    Brain.Screen.newLine();
    Brain.Screen.print("Disk Detect: %s", Optical6.isNearObject() ? "TRUE" : "FALSE");

    // Display the color of the disk if an object is found on row 5
    Brain.Screen.newLine();
    Brain.Screen.print("R: %s", Optical6.color() == red ? "TRUE" : "FALSE");
    Brain.Screen.print(" / B: %s", Optical6.color() == blue ? "TRUE" : "FALSE");
    Brain.Screen.print(" / G: %s", Optical6.color() == green ? "TRUE" : "FALSE");

    // Display the percentage of light reflected back from the Load Sensor on row 6
    Brain.Screen.newLine();
    Brain.Screen.print("Load: %3d", Load.reflectivity());

    // Display the percentage of light reflected back from the Pickup Sensor on row 7
    Brain.Screen.newLine();
    Brain.Screen.print("Pickup: %3d", Pickup.reflectivity());

    // Display the percentage of light reflected back from the Exit Sensor on row 8
    Brain.Screen.newLine();
    Brain.Screen.print("Exit: %3d", Exit.reflectivity());
    wait(0.2, seconds);
  }
  return 0;
}

// sort a red disc
void onRedDetected() {
  // Insert code here for sorting the red discs
}

// sort a green disc
void onGreenDetected() {
  // Insert code here for sorting the green discs
}

// sort a blue disc
void onBlueDetected() {
  // Insert code here for sorting the blue discs
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
    // register emergency stop event handler
  EStop.pressed(onEStopPressed);

  // short wait to make sure the emergency stop event is fully registered
  wait(15, msec);

  // initial device setup
  RoboticArm1.setMasteringValues(0.0, 0.0, 0.0, 0.0);
  RoboticArm1.setToolTipOffset(-0.7, 0.0, -1.0);
  Magnet5.setPower(100);
  Optical6.setLight(ledState::on);
  Optical6.setLightPower(100, percent);
  EntryMotor.setVelocity(70, percent);
  TransportMotor.setVelocity(15, percent);
  ExitMotor.setVelocity(50, percent);
  DiverterMotor.setVelocity(30, percent);
  Brain.Screen.setFont(mono30);

  // start the position and sensor value display task
  vex::task positionSensorDisplayTask(positionSensorDisplay);

  // actual logic for sorting discs by color
  while (true) {
    waitUntil(Optical6.isNearObject());
    if (Optical6.color() == red) {
      onRedDetected();
    }
    else if (Optical6.color() == blue)
    {
      onBlueDetected();
    }
    else if (Optical6.color() == green)
    {
      onGreenDetected();
    }
    wait(5, msec);
  }
}
