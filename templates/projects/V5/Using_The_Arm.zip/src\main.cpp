/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Wed Sep 25 2019                                           */
/*    Description:  Using the Arm (degrees)                                   */
/*                                                                            */
/*    Lift the Arm to a specific position and hold that position. Next,       */
/*    lower the Arm and hold that position. Stop the motor at the end         */
/*    of the program so that the Arm returns to its original position         */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LeftMotor            motor         1
// RightMotor           motor         10
// ClawMotor            motor         3
// ArmMotor             motor         8
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // Take the current position of the Arm as zero
  ArmMotor.setPosition(0, degrees);
  // Move the Arm up and hold the position for 2 seconds
  ArmMotor.spinFor(forward, 90, degrees);
  wait(2, seconds);
  // Lower the Arm and hold that position for 2 seconds
  ArmMotor.spinFor(reverse, 20, degrees);
  wait(2, seconds);
  // Stop the motor. The arm will now lower all the way down due to gravity
  ArmMotor.stop();
}
