/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Mon Aug 24 2020                                           */
/*    Description:  Electromagnet Actions                                     */
/*                                                                            */
/*    This program will demonstrate how to use the Electromagnet              */
/*    to pick up and drop magnetic objects                                    */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    1, 10           
// Magnet2              electromagnet 2               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
  // Depending on the weight of the object that the electromagnet is trying to pick up,
  // the power of the magnet can be adjusted
  Magnet2.setPower(75);

  // Energize the magnet for 1000ms to pick up a magnetic object
  Magnet2.pickup(1000);

  // The object should stay attached to the magnet while the robot drives forward
  Drivetrain.driveFor(forward, 600, mm);

  // Energize the magnet to drop() the object
  Magnet2.drop();
}
