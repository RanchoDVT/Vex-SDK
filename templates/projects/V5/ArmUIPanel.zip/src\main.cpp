/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Tue Mar 16 2021                                           */
/*    Description:  Arm UI Panel                                              */
/*                                                                            */
/*    This example will configure the Workcell Arm and display                */
/*    a basic UI on the V5 Brain's screen that you can configure              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// RoboticArm1          RoboticArm    1, 2, 3, 4, 1, 2, 3, 4
// EStop                bumper        E               
// Magnet5              electromagnet 5               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// Function to run when the V5 Brain's screen is pressed
void onScreenPressed() {
  if (Brain.Screen.xPosition() > 250) {
    if (Brain.Screen.yPosition() > 125) {
      // Blue Box Pressed
    }
    else {
      // Green Box Pressed
    }
  }
  else {
    if (Brain.Screen.yPosition() > 125) {
      // Red Box Pressed
    }
    else {
      // White Box Pressed
    }
  }
}

// Function to run when the emergency stop button is pressed
void onEStopPressed() {
  RoboticArm1.emergencyStop();
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
  // register event handlers
  Brain.Screen.pressed(onScreenPressed);
  EStop.pressed(onEStopPressed);

  wait(15, msec);
  // post event registration

  // draw UI on brain screen
  Brain.Screen.setPenColor(white);
  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(30, 10, 200, 100);
  Brain.Screen.setFillColor(red);
  Brain.Screen.drawRectangle(30, 125, 200, 100);
  Brain.Screen.setFillColor(green);
  Brain.Screen.drawRectangle(250, 10, 200, 100);
  Brain.Screen.setFillColor(blue);
  Brain.Screen.drawRectangle(250, 125, 200, 100);

  // configure the arm
  RoboticArm1.setMasteringValues(0, 0, 0, 0);
  RoboticArm1.setToolTipOffset(-0.7, 0.0, -1.0);
  Magnet5.setPower(100);
}
