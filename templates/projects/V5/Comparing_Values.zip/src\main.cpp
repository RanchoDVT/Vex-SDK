/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Tue Sep 24 2019                                           */
/*    Description:  Comparing Values                                          */
/*                                                                            */
/*   This program looks at the variable to see if it is greater than or       */
/*   less than 10. The message on the screen is updated according to that     */
/*   value. If the value of the variable is greater than 10, the program      */
/*   will print "Value is more than 10" on the screen. If the value of the    */
/*   variable is less than 10, the program will print "Value is less than 10" */
/*   on the screen.                                                           */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int my_variable;
int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  my_variable = 0;
  int repeat_end = 20;
  for (int count = 0; count < repeat_end; count++) {
    // Display the current value of the variable
    Brain.Screen.print("My Variable: ");
    Brain.Screen.print("%d", my_variable);
    Brain.Screen.newLine();
    // Checks to see if the variable is equal to 10
    if (my_variable == 10) {
      Brain.Screen.print("Value equals 10");
    }
    // Checks to see if the variable is greater than 10
    if (my_variable > 10) {
      Brain.Screen.print("Value is more than 10");
    }
    // Checks to see if the variable is less than 10
    if (my_variable < 10) {
      Brain.Screen.print("Value is less than 10");
    }
    wait(2, seconds);
    // Clearing the screen and resetting the cursor
    Brain.Screen.clearScreen();
    Brain.Screen.setCursor(1, 1);

    // Adding one to the current variable value
    my_variable = my_variable + 1;
  }
}
