/* ---------------------------------------------------------------------------- */
/*                                                                              */    
/* 	    Project:        Limit / Bumper Sensing                                  */
/*      Module:         main.cpp                                                */
/*      Author:         VEX                                                     */
/*      Created:        Fri Aug 05 2022                                         */
/*	    Description:    This example will show all of the available commands    */
/*                      for using the Limit and Bumper Sensors                  */
/*                                                                              */                 
/*      Configuration:  V5 Speedbot (Drivetrain 2-motor, No Gyro)               */
/*                      Limit Switch in 3-Wire Port A                           */
/*                      Bumper in 3-Wire Port B                                 */
/*                                                                              */                 
/* ---------------------------------------------------------------------------- */

#include "vex.h"

using namespace vex;

// Brain should be defined by default
brain Brain;


// Robot configuration code.
motor LeftDriveSmart = motor(PORT1, ratio18_1, false);
motor RightDriveSmart = motor(PORT10, ratio18_1, true);
drivetrain Drivetrain = drivetrain(LeftDriveSmart, RightDriveSmart, 319.19, 295, 40, mm, 1);

limit LimitSwitchA = limit(Brain.ThreeWirePort.A);
bumper BumperB = bumper(Brain.ThreeWirePort.B);

int main() {
  // Begin project code
  // Print all Limit Switch and Bumper sensing values to the screen in an infinite loop
  while (true) {
    // Clear the screen and set the cursor to top left corner on each loop
    Brain.Screen.clearScreen();
    Brain.Screen.setCursor(1,1);

    Brain.Screen.print("Limit Switch: %s", LimitSwitchA.pressing() ? "TRUE" : "FALSE");
    Brain.Screen.newLine();

    Brain.Screen.print("Bumper: %s", BumperB.pressing() ? "TRUE" : "FALSE");
    Brain.Screen.newLine();

    // A brief delay to allow text to be printed without distortion or tearing
    wait(50,msec);
  }

}

