/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Tue Oct 01 2019                                           */
/*    Description:  Detect Collisions                                         */
/*                  This program uses the Accelerometer to detect if the robot*/
/*                  is bumped along the y-axis. */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    1, 10           
// AccelYAxis           accelerometer B               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

bool hasStopped = false;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // Set the drive velocity to 50 percent and drive forward.
  Drivetrain.setDriveVelocity(50, percent);
  Drivetrain.drive(forward);

  // Repear forever
  while (true) {
    // If the accelerometer reads greater than .2 gs, and has not stopped yet, stop.
    if (AccelYAxis.acceleration() > .2 && !hasStopped) {
      Drivetrain.stop();
      Brain.Screen.print("Robot hit on Y Axis");
      hasStopped = true;
    }
    wait(5, msec);
  }
}
