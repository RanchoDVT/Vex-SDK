/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Tue Mar 16 2021                                           */
/*    Description:  Arm Install                                               */
/*                                                                            */
/*    This example will help you to setup the potentiometers                  */
/*    for your V5 Workcell arm                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Motor1               motor         1               
// Motor2               motor         2               
// Motor3               motor         3               
// Motor4               motor         4               
// PotentiometerA       pot           A               
// PotentiometerB       pot           B               
// PotentiometerC       pot           C               
// PotentiometerD       pot           D               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int currentState;

bool lockMotors, motor1Target, motor2Target, motor3Target, motor4Target;

float potentiometerValues[4];
float centerPoint[4];

float motorTargets[4][2];

void drawInterface() {
  Brain.Screen.clearScreen();
  Brain.Screen.setFont(mono30);

  // Coast Button
  if (currentState == 1) {
    Brain.Screen.setFillColor(green);
    Brain.Screen.setPenColor(black);
  }
  else {
    Brain.Screen.setFillColor(red);
    Brain.Screen.setPenColor(white);
  }
  Brain.Screen.drawRectangle(20, 165, 120, 60);
  Brain.Screen.setCursor(7, 4);
  Brain.Screen.print("COAST");

  // Hold Button
  if (currentState == 2) {
    Brain.Screen.setFillColor(green);
    Brain.Screen.setPenColor(black);
  }
  else {
    Brain.Screen.setFillColor(red);
    Brain.Screen.setPenColor(white);
  }
  Brain.Screen.drawRectangle(180, 165, 120, 60);
  Brain.Screen.setCursor(7, 15);
  Brain.Screen.print("HOLD");

  // Target Button
  if (currentState == 3) {
    Brain.Screen.setFillColor(green);
    Brain.Screen.setPenColor(black);
  }
  else {
    Brain.Screen.setFillColor(red);
    Brain.Screen.setPenColor(white);
  }
  Brain.Screen.drawRectangle(340, 165, 120, 60);
  Brain.Screen.setCursor(7, 25);
  Brain.Screen.print("TARGET");
}

void jointDisplay() {
  int counterVar = 0;
  Brain.Screen.setFont(mono40);
  
  repeat(4) {
    // Display Joints
    Brain.Screen.setPenColor(white);
    Brain.Screen.setFillColor(transparent);
    Brain.Screen.setCursor(counterVar + 1, 2);
    Brain.Screen.print("Joint %d: %4.0f", counterVar, potentiometerValues[counterVar]);
    Brain.Screen.setCursor(counterVar + 1, 16);

    if (potentiometerValues[counterVar] > motorTargets[counterVar][0] && motorTargets[counterVar][1] > potentiometerValues[counterVar]) {
      Brain.Screen.setPenColor(green);
      Brain.Screen.print(" PASS");
    }
    else {
      Brain.Screen.setPenColor(red);
      Brain.Screen.print(" FAIL");
    }
    if (currentState == 3) {
      Brain.Screen.setCursor(counterVar + 1, 23);
      if (counterVar == 0) {
        if (motor1Target) {
          Brain.Screen.setPenColor(green);
          Brain.Screen.print("Y");
        }
        else {
          Brain.Screen.setPenColor(red);
          Brain.Screen.print("N");
        }
      }
      if (counterVar == 1) {
        if (motor2Target) {
          Brain.Screen.setPenColor(green);
          Brain.Screen.print("Y");
        }
        else {
          Brain.Screen.setPenColor(red);
          Brain.Screen.print("N");
        }
      }
      if (counterVar == 2) {
        if (motor3Target) {
          Brain.Screen.setPenColor(green);
          Brain.Screen.print("Y");
        }
        else {
          Brain.Screen.setPenColor(red);
          Brain.Screen.print("N");
        }
      }
      if (counterVar == 3) {
        if (motor4Target) {
          Brain.Screen.setPenColor(green);
          Brain.Screen.print("Y");
        }
        else {
          Brain.Screen.setPenColor(red);
          Brain.Screen.print("N");
        }
      }
    }
    counterVar = counterVar + 1;
    wait(1, msec);
  }
}

void moveToTarget() {
  Motor1.setVelocity(3.0, percent);
  Motor1.setMaxTorque(100.0, percent);
  Motor1.setStopping(hold);
  Motor2.setVelocity(3.0, percent);
  Motor2.setMaxTorque(100.0, percent);
  Motor2.setStopping(hold);
  Motor3.setVelocity(3.0, percent);
  Motor3.setMaxTorque(100.0, percent);
  Motor3.setStopping(hold);
  Motor4.setVelocity(3.0, percent);
  Motor4.setMaxTorque(100.0, percent);
  Motor4.setStopping(hold);

  // check joint 1
  if (potentiometerValues[0] < centerPoint[0] - 75.0) {
    motor1Target = false;
    Motor1.spin(forward);
  }
  else if (potentiometerValues[0] > centerPoint[0] + 75.0) {
    motor1Target = false;
    Motor1.spin(reverse);
  }
  else {
    motor1Target = true;
    Motor1.stop();
  }

  // check joint 2
  if (potentiometerValues[1] < centerPoint[1] - 75.0) {
    motor2Target = false;
    Motor2.spin(forward);
  }
  else if (potentiometerValues[1] > centerPoint[1] + 75.0) {
    motor2Target = false;
    Motor2.spin(reverse);
  }
  else {
    motor2Target = true;
    Motor2.stop();
  }

  // check joint 3
  if (potentiometerValues[2] < centerPoint[2] - 75.0) {
    motor3Target = false;
    Motor3.spin(forward);
  }
  else if (potentiometerValues[2] > centerPoint[2] + 75.0) {
    motor3Target = false;
    Motor3.spin(reverse);
  }
  else {
    motor3Target = true;
    Motor3.stop();
  }

  // check joint 4
  if (potentiometerValues[3] < centerPoint[3] - 75.0) {
    motor4Target = false;
    Motor4.spin(forward);
  }
  else if (potentiometerValues[3] > centerPoint[3] + 75.0) {
    motor4Target = false;
    Motor4.spin(reverse);
  }
  else {
    motor4Target = true;
    Motor4.stop();
  }
}


// function to call when the screen gets pressed
void onScreenPressed() {
  if (Brain.Screen.yPosition() > 165.0 && 225.0 > Brain.Screen.yPosition()) {
    if (Brain.Screen.xPosition() > 20.0 && 140.0 > Brain.Screen.xPosition()) {
      currentState = 1;
    }
    else if (Brain.Screen.xPosition() > 180.0 && 300.0 > Brain.Screen.xPosition()) {
      currentState = 2;
    }
    else if (Brain.Screen.xPosition() > 340.0 && 460.0 > Brain.Screen.xPosition()) {
      currentState = 3;
    }
  }
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // register screen pressed event handlers
  Brain.Screen.pressed(onScreenPressed);

  wait(15, msec);

  motorTargets[0][0] = 1600.0;
  motorTargets[0][1] = 2000.0;
  motorTargets[1][0] = 1900.0;
  motorTargets[1][1] = 2400.0;
  motorTargets[2][0] = 1700.0;
  motorTargets[2][1] = 2100.0;
  motorTargets[3][0] = 200.0;
  motorTargets[3][1] = 650.0;

  centerPoint[0] = (motorTargets[0][0] + motorTargets[0][1]) / 2.0;
  centerPoint[1] = (motorTargets[1][0] + motorTargets[1][1]) / 2.0;
  centerPoint[2] = (motorTargets[2][0] + motorTargets[2][1]) / 2.0;
  centerPoint[3] = (motorTargets[3][0] + motorTargets[3][1]) / 2.0;
  
  currentState = 1;

  while (true) {
    potentiometerValues[0] = PotentiometerA.angle(percent) * 40.96;
    potentiometerValues[1] = PotentiometerB.angle(percent) * 40.96;
    potentiometerValues[2] = PotentiometerC.angle(percent) * 40.96;
    potentiometerValues[3] = PotentiometerD.angle(percent) * 40.96;

    drawInterface();
    jointDisplay();
    
    if (currentState == 1) {
      // 1 = Coast Mode
      Motor1.setStopping(coast);
      Motor2.setStopping(coast);
      Motor3.setStopping(coast);
      Motor4.setStopping(coast);
      Motor1.stop();
      Motor2.stop();
      Motor3.stop();
      Motor4.stop();
    }
    else if (currentState == 2) {
      // 2 = Holding Mode
      Motor1.setStopping(hold);
      Motor2.setStopping(hold);
      Motor3.setStopping(hold);
      Motor4.setStopping(hold);
      Motor1.stop();
      Motor2.stop();
      Motor3.stop();
      Motor4.stop();
    }
    else if (currentState == 3) {
      // 3 = Move to Target Mode
      moveToTarget();
    }
    wait(0.5, seconds);
  }
  
}
