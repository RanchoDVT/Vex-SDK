# ---------------------------------------------------------------------------- #
#                                                                              #
# 	Module:       {file}                                                       #
# 	Author:       {author}                                                     #
# 	Created:      {date}                                                       #
# 	Description:  {description}                                                #
#                                                                              #
# ---------------------------------------------------------------------------- #

# Library imports
from vex import *

# Brain should be defined by default
brain=Brain()

brain.screen.print("Hello V5")


        
