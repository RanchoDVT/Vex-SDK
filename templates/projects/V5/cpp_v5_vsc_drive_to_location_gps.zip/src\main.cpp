/* ---------------------------------------------------------------------------------------------------------- */
/*                                                                                                            */        
// 	    Project:            Drive to Location (Known Starting Position)                                       */
//      Module:             main.cpp                                                                          */
//      Author:             VEX                                                                               */
//      Created:            Fri Aug 05 2022                                                                   */
//	    Description:        This example will show how to use a GPS Sensor to navigate a V5 Moby Hero Bot     */
//                          to the center of a field by driving along the X-axis then the Y-axis              */
//      Starting Position:  Bottom Right Corner - Facing West                                                 */
/*                                                                                                            */        
/*      Configuration:      V5 Hero Bot (Drivetrain 2-motor, Inertial)                                        */
/*                          Motor Group on Port 2 and 9                                                       */
/*                          Rotation on Port 4                                                                */
/*                          GPS on Port 8                                                                     */
/*                          Distance on Port 12                                                               */
/*                          Optical on Port 19                                                                */
/*                          Distance on Port 20                                                               */
/*                          Bumper on 3-Wire Port A                                                           */
/*                                                                                                            */        
/* ---------------------------------------------------------------------------------------------------------- */

// Include the V5 Library
#include "vex.h"
  
// Allows for easier use of the VEX Library
using namespace vex;

// Brain should be defined by default
brain Brain;

// Robot configuration code.
motor LeftDriveSmart = motor(PORT1, ratio18_1, false);
motor RightDriveSmart = motor(PORT10, ratio18_1, true);
inertial DrivetrainInertial = inertial(PORT3);
smartdrive Drivetrain = smartdrive(LeftDriveSmart, RightDriveSmart, DrivetrainInertial, 319.19, 320, 40, mm, 1);

motor ForkMotorGroupMotorA = motor(PORT2, ratio18_1, false);
motor ForkMotorGroupMotorB = motor(PORT9, ratio18_1, true);
motor_group ForkMotorGroup = motor_group(ForkMotorGroupMotorA, ForkMotorGroupMotorB);

rotation Rotation4 = rotation(PORT4, false);

gps GPS8 = gps(PORT8, 0.00, -240.00, mm, 180);
distance DistanceLeft = distance(PORT12);
distance DistanceRight = distance(PORT20);
optical Optical19 = optical(PORT19);
bumper BumperA = bumper(Brain.ThreeWirePort.A);


void calibrateDrivetrain() {
  wait(200, msec);
  Brain.Screen.print("Calibrating");
  Brain.Screen.newLine();
  Brain.Screen.print("Inertial");
  DrivetrainInertial.calibrate();
  while (DrivetrainInertial.isCalibrating()) {
    wait(25, msec);
  }

  // Clears the screen and returns the cursor to row 1, column 1.
  Brain.Screen.clearScreen();
  Brain.Screen.setCursor(1, 1);
}

void printPosition() {
  // Print GPS position values to the V5 Brain
  Brain.Screen.print("X: %.2f", GPS8.xPosition(mm));
  Brain.Screen.print("  Y: %.2f", GPS8.yPosition(mm));
  Brain.Screen.newLine();
}

int main() {
  // Calibrate the Drivetrain Gyro
  calibrateDrivetrain();

  // Calibrate the GPS Sensor before starting
  GPS8.calibrate();
  while (GPS8.isCalibrating()) { task::sleep(50); }

  // Set the approximate starting position of the robot
  // This helps the GPS sensor know its starting position
  // if it is too close to the field walls to get an accurate initial reading
  GPS8.setLocation(56, -45, inches, 270, degrees);

  // Print the starting position of the robot
  printPosition();
  Drivetrain.drive(forward);

  // Keep driving until the GPS's xPosition passes 0 (horizontal center)
  while (!(GPS8.xPosition(mm) < 0)) {
    wait(0.1, seconds);
  }
  Drivetrain.stop();

  Drivetrain.turnToHeading(90, degrees, true);
  Drivetrain.drive(forward);

  // Keep driving until the GPS's yPosition passes 0 (vertical center)
  while (!(GPS8.yPosition(mm) > 0)) {
    wait(0.1, seconds);
  }
  Drivetrain.stop();

  // Print the ending position of the robot
  printPosition();
}
