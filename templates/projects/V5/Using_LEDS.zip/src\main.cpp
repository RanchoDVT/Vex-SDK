/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Using LEDS                                                */
/*                                                                            */
/*   Turns the LED on/off when the brain screen is pressed.                   */
/*   IMPORTANT: Initially set the LED off as it is set to turn on when        */
/*   the program is started.                                                  */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LEDE                 led           E
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

bool isOn;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  LEDE.off();
  isOn = false;
  while (true) {

    // wait until the screen is pressed
    waitUntil(Brain.Screen.pressing());
    if (isOn) {
      // Turn the LED off and set isOn to false
      LEDE.off();
      isOn = false;
    } else {
      // Turn the LED on and set isOn to true
      LEDE.on();
      isOn = true;
    }
    // wait until the screen is no longer pressed
    waitUntil(!Brain.Screen.pressing());

    wait(5, msec);
  }
}
