/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Tue Mar 16 2021                                           */
/*    Description:  Arm Jogging                                               */
/*                                                                            */
/*    This example will let you control the Workcell Arm by                   */
/*    pressing buttons on the screen of the V5 Brain.                         */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// RoboticArm1          RoboticArm    1, 2, 3, 4, 1, 2, 3, 4
// Magnet5              electromagnet 5               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

float xPos, yPos, zPos;

// User defined function
void printCurrentPosition() {
  Brain.Screen.clearLine(1);
  Brain.Screen.setPenColor(white);
  Brain.Screen.setCursor(1, 1);
  Brain.Screen.print("X: %.1f", xPos);
  Brain.Screen.setCursor(1, 11);
  Brain.Screen.print("Y: %.1f", yPos);
  Brain.Screen.setCursor(1, 21);
  Brain.Screen.print("Z: %.1f", zPos);
}

void onScreenPressed() {
  // when the screen is pressed, check if in a button...
  if (40.0 < Brain.Screen.yPosition() && Brain.Screen.yPosition() < 120.0) {
    if (10.0 < Brain.Screen.xPosition() && Brain.Screen.xPosition() < 90.0) {
      // move X + 0.1
      xPos = xPos + 0.1;
      RoboticArm1.moveToPositionJoint(xPos, yPos, zPos);
      printCurrentPosition();
    } else if (100.0 < Brain.Screen.xPosition() && Brain.Screen.xPosition() < 180.0) {
      // move Y + 0.1
      yPos = yPos + 0.1;
      RoboticArm1.moveToPositionJoint(xPos, yPos, zPos);
      printCurrentPosition();
    } else if (190.0 < Brain.Screen.xPosition() && Brain.Screen.xPosition() < 270.0) {
      // move Z + 0.1
      zPos = zPos + 0.1;
      RoboticArm1.moveToPositionJoint(xPos, yPos, zPos);
      printCurrentPosition();
    } else if (280.0 < Brain.Screen.xPosition() && Brain.Screen.xPosition() < 360.0) {
      // pickup
      Magnet5.pickup(500);
    }
  } else if (130.0 < Brain.Screen.yPosition() && Brain.Screen.yPosition() < 210.0) {
    if (10.0 < Brain.Screen.xPosition() && Brain.Screen.xPosition() < 90.0) {
      // move X - 0.1
      xPos = xPos + -0.1;
      RoboticArm1.moveToPositionJoint(xPos, yPos, zPos);
      printCurrentPosition();
    } else if (100.0 < Brain.Screen.xPosition() && Brain.Screen.xPosition() < 180.0) {
      // move Y - 0.1
      yPos = yPos + -0.1;
      RoboticArm1.moveToPositionJoint(xPos, yPos, zPos);
      printCurrentPosition();
    } else if (190.0 < Brain.Screen.xPosition() && Brain.Screen.xPosition() < 270.0) {
      // move Z - 0.1
      zPos = zPos + -0.1;
      RoboticArm1.moveToPositionJoint(xPos, yPos, zPos);
      printCurrentPosition();
    } else if (280.0 < Brain.Screen.xPosition() && Brain.Screen.xPosition() < 360.0) {
      // drop
      Magnet5.drop();
    }
  }
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

    // register event handlers
  Brain.Screen.pressed(onScreenPressed);

  // enter the mastering values for your arm
  RoboticArm1.setMasteringValues(0, 0, 0, 0);
  RoboticArm1.setToolTipOffset(-0.7, 0.0, -1.0);
  Magnet5.setPower(100);
  xPos = round(RoboticArm1.getAxisPosition(xaxis) * 10.0) / 10.0;
  yPos = round(RoboticArm1.getAxisPosition(yaxis) * 10.0) / 10.0;
  zPos = round(RoboticArm1.getAxisPosition(zaxis) * 10.0) / 10.0;

  // draw buttons
  Brain.Screen.setFillColor(green);
  Brain.Screen.drawRectangle(10, 40, 80, 80);
  Brain.Screen.drawRectangle(10, 130, 80, 80);
  Brain.Screen.drawRectangle(100, 40, 80, 80);
  Brain.Screen.drawRectangle(100, 130, 80, 80);
  Brain.Screen.drawRectangle(190, 40, 80, 80);
  Brain.Screen.drawRectangle(190, 130, 80, 80);
  Brain.Screen.drawRectangle(280, 40, 80, 80);
  Brain.Screen.drawRectangle(280, 130, 80, 80);
  
  // print text in buttons
  Brain.Screen.setPenColor(black);
  Brain.Screen.setCursor(4, 5);
  Brain.Screen.print("X+");
  Brain.Screen.setCursor(4, 14);
  Brain.Screen.print("Y+");
  Brain.Screen.setCursor(4, 23);
  Brain.Screen.print("Z+");
  Brain.Screen.setCursor(4, 30);
  Brain.Screen.print("Pickup");
  Brain.Screen.setCursor(9, 5);
  Brain.Screen.print("X-");
  Brain.Screen.setCursor(9, 14);
  Brain.Screen.print("Y-");
  Brain.Screen.setCursor(9, 23);
  Brain.Screen.print("Z-");
  Brain.Screen.setCursor(9, 31);
  Brain.Screen.print("Drop");
  
  // make sure we are actually at the starting position
  RoboticArm1.moveToPositionJoint(xPos, yPos, zPos);
  
  // print the starting position
  printCurrentPosition();
}
