/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Making Decisions                                          */
/*                                                                            */
/*    This program will run a forever-loop that checks if the RangeFinder     */
/*    detects a wall within 3 inches of the robot, if it does the robot       */
/*    will turn left for 90 degrees. If the robot does not detect a wall      */
/*    in the next 3 inches, it will drive forward for 3 inches.               */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// RangeFinderC         sonar         C, D
// Drivetrain           drivetrain    1, 10, A
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  while (true) {
    if (RangeFinderC.distance(inches) < 3) {
      Drivetrain.turnFor(-90, degrees);
    } else {
      Drivetrain.driveFor(2, inches);
    }
    wait(5, msec);
  }
}
