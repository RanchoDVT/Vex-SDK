/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Project:      Using the Diverters                                       */
/*    Module:       {file}                                                    */
/*    Author:       {author}                                                  */
/*    Created:      {date}                                                    */
/*                                                                            */
/*    Description:  Move a Disk on a conveyor and control the exit of the     */
/*                  Disk using the Pneumatic Diverters                        */
/*                                                                            */
/*    Configuration: CTE Workcell Base + Pneumatics                           */
/*                   6-Axis Robotic Arm in port 10                            */
/*                   Signal Tower in port 6                                   */
/*                   Transport Conveyer Motor in port 2                       */
/*                   Exit Conveyer Motor in port 4                            */
/*                   Pneumatics in port 3                                     */
/*                                                                            */
/*    Setup:         Place a Disk on the Transport Conveyer in line with the  */
/*                   Entry Conveyer                                           */
/*                                                                            */
/*----------------------------------------------------------------------------*/
#include "vex.h"

using namespace vex;
using namespace cte;

// A global instance of vex::brain used for printing to the EXP brain screen
vex::brain       Brain;

// define your global instances of motors and other devices here
arm Arm = arm(PORT10);
signaltower SignalTower = signaltower(PORT6);
pneumatic Pneumatic = pneumatic(PORT3);
motor TransportConveyor = motor(PORT2, true);
motor ExitConveyor = motor(PORT4, false);

void onSignalTowerPressed() {
  Arm.setControlStop(true);
}

void onArmControlStopped() {
  // Visually indicate a controlled stop has occurred with the Signal Tower.
  SignalTower.setColor(signaltower::green, signaltower::off);
  SignalTower.setColor(signaltower::red, signaltower::blink);
  TransportConveyor.stop();
  ExitConveyor.stop();
  Pneumatic.pumpOff();
}

int main() {
    // Initialize the 6-Axis Arm
    Arm.initializeArm();

    // Reset the Signal Tower lights
    SignalTower.setColor(signaltower::all, signaltower::off);
    SignalTower.setColor(signaltower::green, signaltower::on);

    // register event handlers
    SignalTower.pressed(onSignalTowerPressed);
    Arm.controlStopped(onArmControlStopped);
    wait(15, msec);

    // Move the Disk towards the first Diverter
    Pneumatic.extend(cylinder4);
    wait(1.0, seconds);
    TransportConveyor.spin(forward);
    wait(2.0, seconds);

    // Use Diverter to push Disk onto Exit Conveyor
    Pneumatic.retract(cylinder4);

    // Move the Disk on the Exit Conveyor until it falls off
    ExitConveyor.spin(reverse);
    wait(7.0, seconds);
    TransportConveyor.stop();
    ExitConveyor.stop();

}



