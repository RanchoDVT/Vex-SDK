# ---------------------------------------------------------------------------- #
#                                                                              #
# 	Project:     Incremental Movement                                          #
# 	Module:      {file}                                                        #
# 	Author:      {author}                                                      #
# 	Created:     {date}                                                        #
#                                                                              #
#   Description: This example shows the arm moving incrementally along         #
#                the x, y and z axes to pick up and drop off a Disk.           #
#                                                                              #
#   Configuration:  Direct CTE 6-Axis Arm Base                                 #
#                   6-Axis Arm in port 10                                      #
#                   Signal Tower in port 6                                     #
#                                                                              #
#   Setup: Disk on Tile Location 22                                            #
#                                                                              #
# ---------------------------------------------------------------------------- #

# Library imports
from vex import *
from cte import *

# Brain should be defined by default
brain = Brain()

# Robot configuration code
brain_inertial = Inertial()
arm_10 = Arm(Ports.PORT10)
signal_tower_6 = SignalTower(Ports.PORT6)

def on_signal_tower_pressed():
    arm_10.set_control_stop(True)

def on_arm_control_stopped():
    # Visually indicate a controlled stop has occurred with the Signal Tower.
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.RED, SignalTower.BLINK)


def init_arm():
    # Initialize the 6-Axis Arm
    arm_10.initialize_arm()

    # Reset the Signal Tower lights
    signal_tower_6.set_color(SignalTower.ALL, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.ON)

    # register event handlers
    signal_tower_6.pressed(on_signal_tower_pressed)
    arm_10.control_stopped(on_arm_control_stopped)
    # add 15ms delay to make sure events are registered correctly.
    wait(15, MSEC)

# init arm
init_arm()

# Begin project code

# Use the Magnet to pick up the Disk on Tile location 22.
arm_10.set_end_effector_type(Arm.MAGNET)
arm_10.move_to(110, 110, 10)
arm_10.set_end_effector_magnet(True)

# Raise the 6-Axis Arm to verify the Disk has been picked up by the Magnet.
arm_10.move_inc(0, 0, 100)

# Drop off the Disk on Tile location 36.
arm_10.move_inc(100, 100, 0)
arm_10.move_inc(0, 0, -75)
arm_10.set_end_effector_magnet(False)

# Return the 6-Axis Arm to its starting location.
arm_10.move_inc(-110, -110, 75)