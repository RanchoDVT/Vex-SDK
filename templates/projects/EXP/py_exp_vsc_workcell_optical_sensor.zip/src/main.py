# ---------------------------------------------------------------------------- #
#                                                                              #
# 	Project:     Using the Optical Sensor                                      #
# 	Module:      {file}                                                        #
# 	Author:      {author}                                                      #
# 	Created:     {date}                                                        #
#                                                                              #
#   Description: Determining the color of the disk on the conveyors            #
#   based on the optical sensor. Make a decision on where the disk             #
#   goes based on the color                                                    #
#                                                                              #
#   Configuration: CTE Complete Workcell                                       #
#                  6-Axis Robotic Arm in port 10                               #
#                  Signal Tower in port 6                                      #
#                  Transport Conveyor Motor in port 2                          #
#                  Optical Sensor in port 5                                    #
#                  Pneumatics in port 3                                        #
#                  Exit Conveyor Motor in port 4                               #
#                                                                              #
#   Setup: Place a Disk on the Transport Conveyor in line with the             #
#   Entry Conveyor                                                             #
# ---------------------------------------------------------------------------- #

# Library imports
from vex import *
from cte import *

# Brain should be defined by default
brain = Brain()

# Robot configuration code
brain_inertial = Inertial()
arm_10 = Arm(Ports.PORT10)
signal_tower_6 = SignalTower(Ports.PORT6)
transport_conveyor_2 = Motor(Ports.PORT2, True)
optical_sensor_5 = Optical(Ports.PORT5)
pneumatic_3 = Pneumatic(Ports.PORT3)
exit_conveyor_4 = Motor(Ports.PORT4, False)

def on_signal_tower_pressed():
    arm_10.set_control_stop(True)

def on_arm_control_stopped():
    # Visually indicate a controlled stop has occurred with the Signal Tower.
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.RED, SignalTower.BLINK)
    transport_conveyor_2.stop()
    pneumatic_3.pump_off()
    exit_conveyor_4.stop()


def init_arm():
    # Initialize the 6-Axis Arm
    arm_10.initialize_arm()

    # Reset the Signal Tower lights
    signal_tower_6.set_color(SignalTower.ALL, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.ON)

    # register event handlers
    signal_tower_6.pressed(on_signal_tower_pressed)
    arm_10.control_stopped(on_arm_control_stopped)
    # add 15ms delay to make sure events are registered correctly.
    wait(15, MSEC)

# init arm
init_arm()

optical_sensor_5.set_light(LedStateType.ON)
# Move the Disk along the Transport Conveyor until the Optical Sensor detects 
# a Disk
transport_conveyor_2.spin(FORWARD)
while not optical_sensor_5.brightness() > 15:
    wait(5, MSEC)
transport_conveyor_2.stop()
wait(1, SECONDS)

if optical_sensor_5.hue() > 320:
    # For a Red Disk, set the Diverters such that a Disk would be pushed onto 
    # the Exit Conveyor
    pneumatic_3.extend(CYLINDER4)
    pneumatic_3.retract(CYLINDER2)
else:
    # For a Green Disk, set the Diverters such that a Disk would be pushed off 
    # the side
    pneumatic_3.retract(CYLINDER4)
    pneumatic_3.extend(CYLINDER2)
    exit_conveyor_4.spin(REVERSE)

# Move the Disk towards the retracted Diverter
transport_conveyor_2.spin(FORWARD)

