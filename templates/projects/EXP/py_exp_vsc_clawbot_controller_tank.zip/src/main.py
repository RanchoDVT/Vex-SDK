# --------------------------------------------------------------------------------- #
#                                                                                   #
#    Project:           Clawbot Controller with Events                              #
#    Module:            main.py                                                     #
#    Author:            VEX                                                         #
#    Description:       The Left up/down Controller Axis (A) will control the       #
#                       speed of the left motor.                                    #
#                       The Right up/down Controller Axis (D) will control the      #
#                       speed of the right motor.                                   #
#                       The Left up/down Controller Buttons will control            #
#                       the Arm                                                     #
#                       The Right up/down Controller Buttons will control           #
#                       the Claw                                                    #
#                                                                                   #
#    Configuration:     Controller                                                  #
#                       Left Motor in Port 6                                        #
#                       Right Motor in Port 10                                      #
#                       Arm Motor in Port 3                                         #
#                       Claw Motor in Port 4                                        #
#                                                                                   #
# --------------------------------------------------------------------------------- #

# Library imports
from vex import *

# Brain should be defined by default
brain = Brain()

# Robot configuration code
brain_inertial = Inertial()
left_motor = Motor(Ports.PORT6, False)
right_motor = Motor(Ports.PORT10, True)
arm_motor = Motor(Ports.PORT3, False)
claw_motor = Motor(Ports.PORT4, False)
controller = Controller()

# Begin project code
# Callback function when Controller buttonL1 is pressed
def on_L1_pressed():
    # Spinning the arm_motor in forward raises the Arm
    arm_motor.spin(FORWARD)

    # Wait until buttonL1 is released
    while controller.buttonL1.pressing():
        wait(20, MSEC)

    arm_motor.stop()


# Callback function when Controller buttonL2 is pressed
def on_L2_pressed():
    # Spinning the arm_motor in reverse lowers the Arm
    arm_motor.spin(REVERSE)

    # Wait until buttonL2 is released
    while controller.buttonL2.pressing():
        wait(20, MSEC)

    arm_motor.stop()


# Callback function when Controller buttonR1 is pressed
def on_R1_pressed():
    # Spinning the claw_motor forward closes the Claw
    claw_motor.spin(FORWARD)

    # Wait until buttonR1 is released
    while controller.buttonR1.pressing():
        wait(20, MSEC)

    claw_motor.stop()


# Callback function when Controller buttonR2 is pressed
def on_R2_pressed():
    # Spinning the claw_motor in reverse opens the Claw
    claw_motor.spin(REVERSE)

    # Wait until buttonR2 is released
    while controller.buttonR2.pressing():
        wait(20, MSEC)

    claw_motor.stop()


# Register event handlers and pass callback functions
controller.buttonL1.pressed(on_L1_pressed)
controller.buttonL2.pressed(on_L2_pressed)
controller.buttonR1.pressed(on_R1_pressed)
controller.buttonR2.pressed(on_R2_pressed)

# add 15ms delay to make sure events are registered correctly.
wait(15, MSEC)

# Set default motor stopping behavior and velocity
arm_motor.set_stopping(HOLD)
claw_motor.set_stopping(HOLD)
arm_motor.set_velocity(60, PERCENT)
claw_motor.set_velocity(30, PERCENT)

# Loop to check Controller Axis positions and set motor velocity
while True:
    left_motor.set_velocity(controller.axis3.position(), PERCENT)
    right_motor.set_velocity(controller.axis2.position(), PERCENT)

    left_motor.spin(FORWARD)
    right_motor.spin(FORWARD)

    wait(20, MSEC)
