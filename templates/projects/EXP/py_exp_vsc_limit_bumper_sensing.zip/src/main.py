# --------------------------------------------------------------------------------- #
#                                                                                   #
#    Project:           Limit / Bumper Sensing                                      #
#    Module:            main.py                                                     #
#    Author:            VEX                                                         #
#    Description:       This example will show all of the available commands        #
#                       for using the Limit and Bumper Sensors                      #
#                                                                                   #
#    Configuration:     Limit Switch in 3-Wire Port A                               #
#                       Bumper in 3-Wire Port B                                     #
#                                                                                   #
# --------------------------------------------------------------------------------- #

# Library imports
from vex import *

# Brain should be defined by default
brain = Brain()

# Robot configuration code
brain_inertial = Inertial()
limit_switch_a = Limit(brain.three_wire_port.a)
bumper_b = Bumper(brain.three_wire_port.b)

# Begin project code
# Change the font size to fit on the EXP Brain's screen
brain.screen.set_font(FontType.MONO15)

# Print Bumper and Limit Switch sensing values to the screen in a forever block
while True:
    # Clear the screen and set the cursor to top left corner on each loop
    brain.screen.clear_screen()
    brain.screen.set_cursor(1, 1)

    brain.screen.print("Limit Switch:", limit_switch_a.pressing())
    brain.screen.next_row()

    brain.screen.print("Bumper:", bumper_b.pressing())
    brain.screen.next_row()

    # A brief delay to allow text to be printed without distortion or tearing
    wait(0.1, SECONDS)
