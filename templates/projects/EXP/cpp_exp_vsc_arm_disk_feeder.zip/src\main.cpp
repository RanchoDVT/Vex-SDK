/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Project:      Using the Disc Feeder                                     */
/*    Module:       {file}                                                    */
/*    Author:       {author}                                                  */
/*    Created:      {date}                                                    */
/*                                                                            */
/*    Description:  Push a Disk from the Disk Feeder and move it onto         */
/*                  the Transport Conveyor.                                   */
/*                                                                            */
/*    Configuration: CTE Workcell Base + Pneumatics                           */
/*                   6-Axis Robotic Arm in port 10                            */
/*                   Signal Tower in port 6                                   */
/*                   Pneumatics in port 3                                     */
/*                   Entry Conveyor Motor in port 1                           */
/*                                                                            */
/*    Setup:         Place a Disk in the DiskFeeder                           */
/*                                                                            */
/*----------------------------------------------------------------------------*/
#include "vex.h"

using namespace vex;
using namespace cte;

// A global instance of vex::brain used for printing to the EXP brain screen
vex::brain       Brain;

// define your global instances of motors and other devices here
arm Arm = arm(PORT10);
signaltower SignalTower = signaltower(PORT6);
pneumatic Pneumatic = pneumatic(PORT3);
motor EntryConveyor = motor(PORT1, false);

void onSignalTowerPressed() {
  Arm.setControlStop(true);
}

void onArmControlStopped() {
  // Visually indicate a controlled stop has occurred with the Signal Tower.
  SignalTower.setColor(signaltower::green, signaltower::off);
  SignalTower.setColor(signaltower::red, signaltower::blink);
  Pneumatic.pumpOff();
  EntryConveyor.stop();
}

int main() {
    // Initialize the 6-Axis Arm
    Arm.initializeArm();

    // Reset the Signal Tower lights
    SignalTower.setColor(signaltower::all, signaltower::off);
    SignalTower.setColor(signaltower::green, signaltower::on);

    // register event handlers
    SignalTower.pressed(onSignalTowerPressed);
    Arm.controlStopped(onArmControlStopped);
    wait(15, msec);

    // Push one Disk onto the Entry Conveyor
    Pneumatic.extend(cylinder1);
    wait(1.0, seconds);
    Pneumatic.retract(cylinder1);
    EntryConveyor.setVelocity(75.0, percent);

    // Move the Disk from the Entry Conveyor to the Transport Conveyor
    EntryConveyor.spin(forward);
    wait(3.0, seconds);
    EntryConveyor.stop();


}



