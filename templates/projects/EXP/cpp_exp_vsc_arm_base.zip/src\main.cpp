/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       {file}                                                    */
/*    Author:       {author}                                                  */
/*    Created:      {date}                                                    */
/*    Description:  {description}                                             */
/*                                                                            */
/*    Configuration:                                                           */
/*                  6-Axis Robotic Arm in port 10                             */
/*                  Signal Tower in port 6                                    */
/*                                                                            */
/*----------------------------------------------------------------------------*/
#include "vex.h"

using namespace vex;
using namespace cte;

// A global instance of vex::brain used for printing to the EXP brain screen
vex::brain       Brain;

// define your global instances of motors and other devices here
arm Arm = arm(PORT10);
signaltower SignalTower = signaltower(PORT6);

void onSignalTowerPressed() {
  Arm.setControlStop(true);
}

void onArmControlStopped() {
  // Visually indicate a controlled stop has occurred with the Signal Tower.
  SignalTower.setColor(signaltower::green, signaltower::off);
  SignalTower.setColor(signaltower::red, signaltower::blink);
}

int main() {
    // Initialize the 6-Axis Arm
    Arm.initializeArm();

    // Reset the Signal Tower lights
    SignalTower.setColor(signaltower::all, signaltower::off);
    SignalTower.setColor(signaltower::green, signaltower::on);

    // register event handlers
    SignalTower.pressed(onSignalTowerPressed);
    Arm.controlStopped(onArmControlStopped);
    wait(15, msec);

}



