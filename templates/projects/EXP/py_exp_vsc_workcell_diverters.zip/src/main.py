# ---------------------------------------------------------------------------- #
#                                                                              #
# 	Project:     Using the Diverters                                           #
# 	Module:      {file}                                                        #
# 	Author:      {author}                                                      #
# 	Created:     {date}                                                        #
#                                                                              #
#   Description: Move a Disk on a conveyor and control the exit of the         #
#                Disk using the Pneumatic Diverters                            #
#                                                                              #
#   Configuration: CTE Workcell Base + Pneumatics                              #
#                  6-Axis Robotic Arm in port 10                               #
#                  Signal Tower in port 6                                      #
#                  Transport Conveyor Motor in port 2                          #
#                  Exit Conveyor Motor in port 4                               #
#                  Pneumatics in port 3                                        #
#                                                                              #
#   Setup: Place a Disk on the Transport Conveyor in line with the Entry       #
#          Conveyor                                                            #
#                                                                              #
# ---------------------------------------------------------------------------- #

# Library imports
from vex import *
from cte import *

# Brain should be defined by default
brain = Brain()

# Robot configuration code
brain_inertial = Inertial()
arm_10 = Arm(Ports.PORT10)
signal_tower_6 = SignalTower(Ports.PORT6)
pneumatic_3 = Pneumatic(Ports.PORT3)
exit_conveyor_4 = Motor(Ports.PORT4, False)
transport_conveyor_2 = Motor(Ports.PORT2, True)


def on_signal_tower_pressed():
    arm_10.set_control_stop(True)

def on_arm_control_stopped():
    # Visually indicate a controlled stop has occurred with the Signal Tower.
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.RED, SignalTower.BLINK)
    transport_conveyor_2.stop()
    pneumatic_3.pump_off()
    exit_conveyor_4.stop()


def init_arm():
    # Initialize the 6-Axis Arm
    arm_10.initialize_arm()

    # Reset the Signal Tower lights
    signal_tower_6.set_color(SignalTower.ALL, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.ON)

    # register event handlers
    signal_tower_6.pressed(on_signal_tower_pressed)
    arm_10.control_stopped(on_arm_control_stopped)
    # add 15ms delay to make sure events are registered correctly.
    wait(15, MSEC)

# init arm
init_arm()

# Begin project code

# Move the Disk towards the first Diverter
pneumatic_3.extend(CYLINDER4)
wait(1, SECONDS)
transport_conveyor_2.spin(FORWARD)
wait(2, SECONDS)
# Use Diverter to push Disk onto Exit Conveyor
pneumatic_3.retract(CYLINDER4)
# Move the Disk on the Exit Conveyor until it falls off
exit_conveyor_4.spin(REVERSE)
wait(7, SECONDS)
transport_conveyor_2.stop()
exit_conveyor_4.stop()

