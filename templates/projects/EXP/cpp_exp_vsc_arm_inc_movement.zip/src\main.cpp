/*----------------------------------------------------------------------------*/
/*    Project:      Incremental Movement                                      */
/*    Module:       {file}                                                    */
/*    Author:       {author}                                                  */
/*    Created:      {date}                                                    */
/*                                                                            */
/*    Description:  This example shows the arm moving incrementally along     */
/*                  the x, y and z axes to pick up and drop off a Disk.       */
/*                                                                            */
/*    Configuration:  Direct CTE 6-Axis Arm Base                              */
/*                    6-Axis Arm in port 10                                   */
/*                    Signal Tower in port 6                                  */
/*                                                                            */
/*    Setup: Disk on Tile Location 22                                         */
/*                                                                            */
/*----------------------------------------------------------------------------*/
#include "vex.h"

using namespace vex;
using namespace cte;

// A global instance of vex::brain used for printing to the EXP brain screen
vex::brain       Brain;

// define your global instances of motors and other devices here
arm Arm = arm(PORT10);
signaltower SignalTower = signaltower(PORT6);

void onSignalTowerPressed() {
  Arm.setControlStop(true);
}

void onArmControlStopped() {
  // Visually indicate a controlled stop has occurred with the Signal Tower.
  SignalTower.setColor(signaltower::green, signaltower::off);
  SignalTower.setColor(signaltower::red, signaltower::blink);
}

int main() {
    // Initialize the 6-Axis Arm
    Arm.initializeArm();

    // Reset the Signal Tower lights
    SignalTower.setColor(signaltower::all, signaltower::off);
    SignalTower.setColor(signaltower::green, signaltower::on);

    // register event handlers
    SignalTower.pressed(onSignalTowerPressed);
    Arm.controlStopped(onArmControlStopped);

    // Use the Magnet to pick up the Disk on Tile location 22.
    Arm.setEndEffectorType(magnet);
    Arm.moveTo(110.0, 110.0, 10.0, true);
    Arm.setEndEffectorMagnet(true);

    // Raise the 6-Axis Arm to verify the Disk has been picked up by the Magnet.
    Arm.moveInc(0.0, 0.0, 100.0, true);

    // Drop off the Disk on Tile location 36.
    Arm.moveInc(100.0, 100.0, 0.0, true);
    Arm.moveInc(0.0, 0.0, -75.0, true);
    Arm.setEndEffectorMagnet(false);
    
    // Return the 6-Axis Arm to its starting location.
    Arm.moveInc(-110.0, -110.0, 75.0, true);

}



