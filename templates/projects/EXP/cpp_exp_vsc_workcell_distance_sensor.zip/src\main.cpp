/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Project:      Using the Distance Sensor with Workcell                   */
/*    Module:       {file}                                                    */
/*    Author:       {author}                                                  */
/*    Created:      {date}                                                    */
/*                                                                            */
/*    Description:  Determining the location of a disk on the conveyor        */
/*                  based on the distance sensor.                             */
/*                                                                            */
/*    Configuration: CTE Complete Workcell                                    */
/*                   6-Axis Robotic Arm in port 10                            */
/*                   Signal Tower in port 6                                   */
/*                   Transport Conveyor Motor in port 2                       */
/*                   Distance Sensor in port 7                                */
/*                                                                            */
/*    Setup:         Place a Disk on the Transport Conveyor in line with the  */
/*                   Entry Conveyor                                           */
/*                                                                            */
/*----------------------------------------------------------------------------*/
#include "vex.h"

using namespace vex;
using namespace cte;

// A global instance of vex::brain used for printing to the EXP brain screen
vex::brain       Brain;

// define your global instances of motors and other devices here
arm Arm = arm(PORT10);
signaltower SignalTower = signaltower(PORT6);
motor TransportConveyor = motor(PORT2, true);
distance DistanceSensor = distance(PORT7);

void onSignalTowerPressed() {
  Arm.setControlStop(true);
}

void onArmControlStopped() {
  // Visually indicate a controlled stop has occurred with the Signal Tower.
  SignalTower.setColor(signaltower::green, signaltower::off);
  SignalTower.setColor(signaltower::red, signaltower::blink);
  TransportConveyor.stop();
}

int main() {
    // Initialize the 6-Axis Arm
    Arm.initializeArm();

    // Reset the Signal Tower lights
    SignalTower.setColor(signaltower::all, signaltower::off);
    SignalTower.setColor(signaltower::green, signaltower::on);

    // register event handlers
    SignalTower.pressed(onSignalTowerPressed);
    Arm.controlStopped(onArmControlStopped);
    wait(15, msec);

    // Move the Disk on the Transport Conveyor until the Distance Sensor detects 
    // the Disk within 50 mm
    TransportConveyor.spin(forward);
    waitUntil((DistanceSensor.objectDistance(mm) < 50.0));
    TransportConveyor.stop();

}



