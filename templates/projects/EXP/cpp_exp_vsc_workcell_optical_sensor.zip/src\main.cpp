/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Project:      Using the Optical Sensor                                  */
/*    Module:       {file}                                                    */
/*    Author:       {author}                                                  */
/*    Created:      {date}                                                    */
/*                                                                            */
/*    Description:  Determining the color of the disk on the conveyors based  */
/*                  on the optical sensor – make a decision on where the disk */
/*                  goes based on the color                                   */
/*                                                                            */
/*    Configuration: CTE Complete Workcell                                    */
/*                   6-Axis Robotic Arm in port 10                            */
/*                   Signal Tower in port 6                                   */
/*                   Transport Conveyor Motor in port 2                       */
/*                   Optical Sensor in port 5                                 */
/*                   Pneumatics in port 3                                     */
/*                   Exit Conveyor Motor in port 4                            */
/*                                                                            */
/*    Setup:        Place a Disk on the Transport Conveyor in line with the   */
/*                  Entry Conveyor                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/
#include "vex.h"

using namespace vex;
using namespace cte;

// A global instance of vex::brain used for printing to the EXP brain screen
vex::brain       Brain;

// define your global instances of motors and other devices here
arm Arm = arm(PORT10);
signaltower SignalTower = signaltower(PORT6);
motor TransportConveyor = motor(PORT2, true);
optical OpticalSensor = optical(PORT5);
pneumatic Pneumatic = pneumatic(PORT3);
motor ExitConveyor = motor(PORT4, false);

void onSignalTowerPressed() {
  Arm.setControlStop(true);
}

void onArmControlStopped() {
  // Visually indicate a controlled stop has occurred with the Signal Tower.
  SignalTower.setColor(signaltower::green, signaltower::off);
  SignalTower.setColor(signaltower::red, signaltower::blink);
  TransportConveyor.stop();
  Pneumatic.pumpOff();
  ExitConveyor.stop();
}

int main() {
    // Initialize the 6-Axis Arm
    Arm.initializeArm();

    // Reset the Signal Tower lights
    SignalTower.setColor(signaltower::all, signaltower::off);
    SignalTower.setColor(signaltower::green, signaltower::on);

    // register event handlers
    SignalTower.pressed(onSignalTowerPressed);
    Arm.controlStopped(onArmControlStopped);
    wait(15, msec);

    OpticalSensor.setLight(ledState::on);

    // Move the Disk along the Transport Conveyor until the Optical Sensor 
    // detects a Disk
    TransportConveyor.spin(forward);
    waitUntil((OpticalSensor.brightness() > 15.0));
    TransportConveyor.stop();
    wait(1.0, seconds);

    if (OpticalSensor.hue() > 320.0) {
        // For a Red Disk, set the Diverters such that a Disk would be pushed onto 
        // the Exit Conveyor
        Pneumatic.extend(cylinder4);
        Pneumatic.retract(cylinder2);
    }
    else {
        // For a Green Disk, set the Diverters such that a Disk would be pushed 
        // off the side
        Pneumatic.retract(cylinder4);
        Pneumatic.extend(cylinder2);
        ExitConveyor.spin(reverse);
    }
    
    // Move the Disk towards the retracted Diverter
    TransportConveyor.spin(forward);

}



