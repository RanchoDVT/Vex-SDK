# ---------------------------------------------------------------------------- #
#                                                                              #
# 	Project:     Using the Conveyor Motors                                     #
# 	Module:      {file}                                                        #
# 	Author:      {author}                                                      #
# 	Created:     {date}                                                        #
#                                                                              #
#   Description: Determining the location of a disk on the conveyor based on   #
#                the distance sensor.                                          # 
#                                                                              #
#   Configuration: CTE Complete Workcell                                       #
#                 6-Axis Robotic Arm in port 10                                #
#                 Signal Tower in port 6                                       #
#                 Transport Conveyor Motor in port 2                           #
#                 Distance Sensor in port 7                                    #
#                                                                              #
#   Setup: Place a Disk on the Transport Conveyor in line with the Entry       #
#          Conveyor                                                            #
#                                                                              #
# ---------------------------------------------------------------------------- #

# Library imports
from vex import *
from cte import *

# Brain should be defined by default
brain = Brain()

# Robot configuration code
brain_inertial = Inertial()
arm_10 = Arm(Ports.PORT10)
signal_tower_6 = SignalTower(Ports.PORT6)
transport_conveyor_2 = Motor(Ports.PORT2, False)
distance_sensor_7 = Distance(Ports.PORT7)


def on_signal_tower_pressed():
    arm_10.set_control_stop(True)

def on_arm_control_stopped():
    # Visually indicate a controlled stop has occurred with the Signal Tower.
    arm_10.set_control_stop(True)


def init_arm():
    # Initialize the 6-Axis Arm
    arm_10.initialize_arm()

    # Reset the Signal Tower lights
    signal_tower_6.set_color(SignalTower.ALL, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.ON)

    # register event handlers
    signal_tower_6.pressed(on_signal_tower_pressed)
    arm_10.control_stopped(on_arm_control_stopped)
    # add 15ms delay to make sure events are registered correctly.
    wait(15, MSEC)

# init arm
init_arm()

# Begin project code

# Move the Disk on the Transport Conveyor until the Distance Sensor detects 
# the Disk within 50 mm
transport_conveyor_2.spin(FORWARD)
while not distance_sensor_7.object_distance(MM) < 50:
    wait(5, MSEC)
transport_conveyor_2.stop()

