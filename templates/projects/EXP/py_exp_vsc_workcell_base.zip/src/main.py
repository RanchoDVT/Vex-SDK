# ---------------------------------------------------------------------------- #
#                                                                              #
# 	Module:      {file}                                                        #
# 	Author:      {author}                                                      #
# 	Created:     {date}                                                        #
#	Description: {description}                                                 #
#                                                                              #
#   Configuration: EXP CTE Workcell Base                                       #
#                  EntryConveyor in Port 1                                     #
#                  TransportConveyor in Port 2                                 #
#                  SignalTower in Port 6                                       #
#                  Arm in Port 10                                              #
#                                                                              #
# ---------------------------------------------------------------------------- #

# Library imports
from vex import *
from cte import *

# Brain should be defined by default
brain = Brain()

# Robot configuration code
brain_inertial = Inertial()
arm_10 = Arm(Ports.PORT10)
entry_conveyor_1 = Motor(Ports.PORT1, False)
transport_conveyor_2 = Motor(Ports.PORT2, True)
signal_tower_6 = SignalTower(Ports.PORT6)

def on_signal_tower_pressed():
    arm_10.set_control_stop(True)


def on_arm_control_stopped():
    # Visually indicate a controlled stop has occurred with the Signal Tower.
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.RED, SignalTower.BLINK)
    entry_conveyor_1.stop()
    transport_conveyor_2.stop()


def init_arm():
    # Initialize the 6-Axis Arm
    arm_10.initialize_arm()

    # Reset the Signal Tower lights
    signal_tower_6.set_color(SignalTower.ALL, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.ON)

    # register event handlers
    signal_tower_6.pressed(on_signal_tower_pressed)
    arm_10.control_stopped(on_arm_control_stopped)
    # add 15ms delay to make sure events are registered correctly.
    wait(15, MSEC)

# init arm
init_arm()

# Begin project code


