# ---------------------------------------------------------------------------- #
#                                                                              #
# 	Project:     Moving to Position                                            #
# 	Module:      {file}                                                        #
# 	Author:      {author}                                                      #
# 	Created:     {date}                                                        #
#                                                                              #
#   Description: This example shows the 6-Axis Arm moving to                   #
#                Tile locations 26 and 11 using Move to position               #
#                blocks.                                                       #
#                                                                              #
#   Configuration:  Brain CTE 6-Axis Arm Base                                  #
#                   6-Axis Arm in port 10                                      #
#                   Signal Tower in port 6                                     #
#                                                                              #
#   Setup:          Disk on Tile Location 22                                   #
#                                                                              #
# ---------------------------------------------------------------------------- #

# Library imports
from vex import *
from cte import *

# Brain should be defined by default
brain = Brain()

# Robot configuration code
brain_inertial = Inertial()
arm_10 = Arm(Ports.PORT10)
signal_tower_6 = SignalTower(Ports.PORT6)

def on_signal_tower_pressed():
    arm_10.set_control_stop(True)

def on_arm_control_stopped():
    # Visually indicate a controlled stop has occurred with the Signal Tower.
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.RED, SignalTower.BLINK)

def init_arm():
    # Initialize the 6-Axis Arm
    arm_10.initialize_arm()

    # Reset the Signal Tower lights
    signal_tower_6.set_color(SignalTower.ALL, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.ON)

    # register event handlers
    signal_tower_6.pressed(on_signal_tower_pressed)
    arm_10.control_stopped(on_arm_control_stopped)
    # add 15ms delay to make sure events are registered correctly.
    wait(15, MSEC)

# init arm
init_arm()

# Move to Tile location 26.
arm_10.move_to(144, 8, 0)

# Move to Tile location 11.
arm_10.move_to(144, 8, 100)
arm_10.move_to(-15, 159, 0)