/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Project:      Using the Arm with the Optical Sensor                     */
/*    Module:       {file}                                                    */
/*    Author:       {author}                                                  */
/*    Created:      {date}                                                    */
/*                                                                            */
/*    Description:  Sort disk based on color and change the location the      */
/*                  disk is moved.                                            */
/*                                                                            */
/*    Configuration: Brain CTE 6-Axis Arm Base + Optical                      */
/*                   6-Axis Robotic Arm in port 10                            */ 
/*                   Signal Tower in port 6                                   */
/*                   Optical Sensor in port   5                               */
/*                                                                            */
/*    Setup:        Place a Disk on the Pallet on the Right                   */
/*                                                                            */
/*----------------------------------------------------------------------------*/
#include "vex.h"

using namespace vex;
using namespace cte;

// A global instance of vex::brain used for printing to the EXP brain screen
vex::brain       Brain;

// define your global instances of motors and other devices here
arm Arm = arm(PORT10);
signaltower SignalTower = signaltower(PORT6);
optical OpticalSensor = optical(PORT5);

void onSignalTowerPressed() {
  Arm.setControlStop(true);
}

void onArmControlStopped() {
  // Visually indicate a controlled stop has occurred with the Signal Tower.
  SignalTower.setColor(signaltower::green, signaltower::off);
  SignalTower.setColor(signaltower::red, signaltower::blink);
}

int main() {
    // Initialize the 6-Axis Arm
    Arm.initializeArm();

    // Reset the Signal Tower lights
    SignalTower.setColor(signaltower::all, signaltower::off);
    SignalTower.setColor(signaltower::green, signaltower::on);

    // register event handlers
    SignalTower.pressed(onSignalTowerPressed);
    Arm.controlStopped(onArmControlStopped);
    wait(15, msec);

    OpticalSensor.setLight(ledState::on);

    // Position the Arm above the Disk
    Arm.setEndEffectorType(magnet);
    Arm.moveTo(170.0, 0.0, 50.0, true);
    wait(0.5, seconds);

    // Pick up the Disk using the Magnet End Effector
    Arm.setEndEffectorMagnet(true);
    Arm.moveInc(0.0, 0.0, -15.0, true);
    Arm.moveInc(0.0, 0.0, 20.0, true);
    wait(0.5, seconds);

    // Move the Arm to a position above the Optical Sensor
    Arm.moveTo(150.0, 80.0, 60.0, true);

    // If the Disk is Green, Move it to the left pallet. If it is not, Move the 
    // Disk back to the right Pallet.
    if (OpticalSensor.hue() > 70.0) {
        Arm.moveTo(170.0, 160.0, 40.0, true);
    }
    else {
        Arm.moveTo(170.0, 0.0, 50.0, true);
    }

    // Release the Disk and Move the Arm back to the Safe Position
    Arm.setEndEffectorMagnet(false);
    wait(1.0, seconds);
    Arm.moveTo(120.0, 0.0, 100.0, true);

}



