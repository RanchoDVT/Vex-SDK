/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Project:      Moving to Position                                        */
/*    Module:       {file}                                                    */
/*    Author:       {author}                                                  */
/*    Created:      {date}                                                    */
/*                                                                            */
/*    Description:  This example shows the 6-Axis Arm moving to Tile          */
/*                  locations 26 and 11 using Move to position blocks.        */
/*                                                                            */
/*    Configuration:  Brain CTE 6-Axis Arm Base                               */
/*                    6-Axis Arm in port 10                                   */
/*                    Signal Tower in port 6                                  */
/*                                                                            */
/*----------------------------------------------------------------------------*/
#include "vex.h"

using namespace vex;
using namespace cte;

// A global instance of vex::brain used for printing to the EXP brain screen
vex::brain       Brain;

// define your global instances of motors and other devices here
arm Arm = arm(PORT10);
signaltower SignalTower = signaltower(PORT6);

void onSignalTowerPressed() {
  Arm.setControlStop(true);
}

void onArmControlStopped() {
  // Visually indicate a controlled stop has occurred with the Signal Tower.
  SignalTower.setColor(signaltower::green, signaltower::off);
  SignalTower.setColor(signaltower::red, signaltower::blink);
}

int main() {
    // Initialize the 6-Axis Arm
    Arm.initializeArm();

    // Reset the Signal Tower lights
    SignalTower.setColor(signaltower::all, signaltower::off);
    SignalTower.setColor(signaltower::green, signaltower::on);

    // register event handlers
    SignalTower.pressed(onSignalTowerPressed);
    Arm.controlStopped(onArmControlStopped);
    wait(15, msec);

    // Move to Tile location 26.
    Arm.moveTo(144.0, 8.0, 0.0, true);

    // Move to Tile location 11.
    Arm.moveTo(144.0, 8.0, 100.0, true);
    Arm.moveTo(-15.0, 159.0, 0.0, true);

}



