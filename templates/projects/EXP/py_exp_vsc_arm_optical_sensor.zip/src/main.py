# ---------------------------------------------------------------------------- #
#                                                                              #
# 	Project:     Using the Arm with the Optical Sensor                         #
# 	Module:      {file}                                                        #
# 	Author:      {author}                                                      #
# 	Created:     {date}                                                        #
#                                                                              #
#   Description: This example shows the 6-Axis Arm moving to                   #
#                Tile locations 26 and 11 using Move to position               #
#                blocks.                                                       #
#                                                                              #
#   Configuration:  Brain CTE 6-Axis Arm Base                                  #
#                   6-Axis Arm in port 10                                      #
#                   Signal Tower in port 6                                     #
#                                                                              #
#   Setup: Place a Disk on the Pallet on the Right                             #
#                                                                              #
# ---------------------------------------------------------------------------- #

# Library imports
from vex import *
from cte import *

# Brain should be defined by default
brain = Brain()

# Robot configuration code
brain_inertial = Inertial()
arm_10 = Arm(Ports.PORT10)
signal_tower_6 = SignalTower(Ports.PORT6)
optical_sensor_5 = Optical(Ports.PORT5)

def on_signal_tower_pressed():
    arm_10.set_control_stop(True)

def on_arm_control_stopped():
    # Visually indicate a controlled stop has occurred with the Signal Tower.
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.RED, SignalTower.BLINK)

def init_arm():
    # Initialize the 6-Axis Arm
    arm_10.initialize_arm()

    # Reset the Signal Tower lights
    signal_tower_6.set_color(SignalTower.ALL, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.ON)

    # register event handlers
    signal_tower_6.pressed(on_signal_tower_pressed)
    arm_10.control_stopped(on_arm_control_stopped)
    # add 15ms delay to make sure events are registered correctly.
    wait(15, MSEC)

# init arm
init_arm()

# Begin project code

optical_sensor_5.set_light(LedStateType.ON)
# Position the Arm above the Disk
arm_10.set_end_effector_type(Arm.MAGNET)
arm_10.move_to(170, 0, 50)
wait(0.5, SECONDS)
# Pick up the Disk using the Magnet End Effector
arm_10.set_end_effector_magnet(True)
arm_10.move_inc(0, 0, -20)
arm_10.move_inc(0, 0, 20)
wait(0.5, SECONDS)
# Move the Arm to a position above the Optical Sensor
arm_10.move_to(150, 80, 60)
# If the Disk is Green, Move it to the left pallet. If it is not, Move the 
# Disk back to the right Pallet.
if optical_sensor_5.hue() > 70:
    arm_10.move_to(170, 160, 40)
else:
    arm_10.move_to(170, 0, 50)
# Release the Disk and Move the Arm back to the Safe Position
arm_10.set_end_effector_magnet(False)
wait(1, SECONDS)
arm_10.move_to(120, 0, 100)