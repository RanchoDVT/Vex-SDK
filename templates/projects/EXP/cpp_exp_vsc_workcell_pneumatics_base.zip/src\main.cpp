/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       {file}                                                    */
/*    Author:       {author}                                                  */
/*    Created:      {date}                                                    */
/*    Description:  {description}                                             */
/*                                                                            */
/*    Configuration: EXP CTE Workcell Base + Pneumaics                        */
/*                   EntryConveyor in Port 1                                  */
/*                   TransportConveyor in Port 2                              */
/*                   SignalTower in Port 6                                    */
/*                   Arm in Port 10                                           */
/*                   Pneumatics in Port 3                                     */
/*                   ExitConveyor in Port 4                                   */
/*                                                                            */
/*----------------------------------------------------------------------------*/
#include "vex.h"

using namespace vex;
using namespace cte;

// A global instance of vex::brain used for printing to the EXP brain screen
vex::brain       Brain;

// define your global instances of motors and other devices here
arm Arm = arm(PORT10);
signaltower SignalTower = signaltower(PORT6);
motor EntryConveyor = motor(PORT1, false);
motor TransportConveyor = motor(PORT2, true);
pneumatic Pneumatic = pneumatic(PORT3);
motor ExitConveyor = motor(PORT4, false);

void onSignalTowerPressed() {
  Arm.setControlStop(true);
  Pneumatic.pumpOff();
  EntryConveyor.stop();
  TransportConveyor.stop();
  ExitConveyor.stop();
}

void onArmControlStopped() {
  // Visually indicate a controlled stop has occurred with the Signal Tower.
  SignalTower.setColor(signaltower::green, signaltower::off);
  SignalTower.setColor(signaltower::red, signaltower::blink);
}

int main() {
    // Initialize the 6-Axis Arm
    Arm.initializeArm();

    // Reset the Signal Tower lights
    SignalTower.setColor(signaltower::all, signaltower::off);
    SignalTower.setColor(signaltower::green, signaltower::on);

    // register event handlers
    SignalTower.pressed(onSignalTowerPressed);
    Arm.controlStopped(onArmControlStopped);
    wait(15, msec);

}



