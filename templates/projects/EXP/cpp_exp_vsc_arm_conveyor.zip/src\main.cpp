/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Project:      Using the Conveyor Motors                                 */
/*    Module:       {file}                                                    */
/*    Author:       {author}                                                  */
/*    Created:      {date}                                                    */
/*                                                                            */
/*    Description:  Moving a disk with the conveyors                          */
/*                                                                            */
/*    Configuration: CTE Workcell Base                                        */
/*                   6-Axis Robotic Arm in port 10                            */
/*                   Signal Tower in port 6                                   */ 
/*                   Entry Conveyor Motor in port 1                           */
/*                   Transport Conveyor Motor in port 2                       */
/*                                                                            */
/*    Setup:         Place a Disk in the Disk Feeder                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/
#include "vex.h"

using namespace vex;
using namespace cte;

// A global instance of vex::brain used for printing to the EXP brain screen
vex::brain       Brain;

// define your global instances of motors and other devices here
arm Arm = arm(PORT10);
signaltower SignalTower = signaltower(PORT6);
motor TransportConveyor = motor(PORT2, true);
motor EntryConveyor = motor(PORT1, false);

void onSignalTowerPressed() {
  Arm.setControlStop(true);
}

void onArmControlStopped() {
  // Visually indicate a controlled stop has occurred with the Signal Tower.
  SignalTower.setColor(signaltower::green, signaltower::off);
  SignalTower.setColor(signaltower::red, signaltower::blink);
  EntryConveyor.stop();
  TransportConveyor.stop();

}

int main() {
    // Initialize the 6-Axis Arm
    Arm.initializeArm();

    // Reset the Signal Tower lights
    SignalTower.setColor(signaltower::all, signaltower::off);
    SignalTower.setColor(signaltower::green, signaltower::on);

    // register event handlers
    SignalTower.pressed(onSignalTowerPressed);
    Arm.controlStopped(onArmControlStopped);
    wait(15, msec);

    // Move the Disk from the Entry Conveyor onto the Transport Conveyor
    EntryConveyor.spin(forward);
    wait(5.0, seconds);
    EntryConveyor.stop();

    // Move the Disk along the Transport Conveyor until it passes the first turn 
    // and then stop
    TransportConveyor.spin(forward);
    wait(2.0, seconds);
    TransportConveyor.stop();
}



