# ---------------------------------------------------------------------------- #
#                                                                              #
# 	Project:     Using the Disc Feeder                                         #
# 	Module:      {file}                                                        #
# 	Author:      {author}                                                      #
# 	Created:     {date}                                                        #
#                                                                              #
#   Description: This example shows the 6-Axis Arm moving to                   #
#                Tile locations 26 and 11 using Move to position               #
#                blocks.                                                       #
#                                                                              #
#   Configuration: CTE Workcell Base + Pneumatics                              #
#                  6-Axis Robotic Arm in port 10                               #
#                  Signal Tower in port 6                                      #
#                  Pneumatics in port 3                                        #
#                  Entry Conveyor Motor in port 1                              #
#                                                                              #
#   Setup: Place a Disk in the DiskFeeder                                      #
#                                                                              #
# ---------------------------------------------------------------------------- #

# Library imports
from vex import *
from cte import *

# Brain should be defined by default
brain = Brain()

# Robot configuration code
brain_inertial = Inertial()
arm_10 = Arm(Ports.PORT10)
signal_tower_6 = SignalTower(Ports.PORT6)
pneumatic_3 = Pneumatic(Ports.PORT3)
entry_conveyor_1 = Motor(Ports.PORT1, False)

def on_signal_tower_pressed():
    arm_10.set_control_stop(True)

def on_arm_control_stopped():
    # Visually indicate a controlled stop has occurred with the Signal Tower.
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.RED, SignalTower.BLINK)
    pneumatic_3.pump_off()
    entry_conveyor_1.stop()

def init_arm():
    # Initialize the 6-Axis Arm
    arm_10.initialize_arm()

    # Reset the Signal Tower lights
    signal_tower_6.set_color(SignalTower.ALL, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.ON)

    # register event handlers
    signal_tower_6.pressed(on_signal_tower_pressed)
    arm_10.control_stopped(on_arm_control_stopped)
    # add 15ms delay to make sure events are registered correctly.
    wait(15, MSEC)

# init arm
init_arm()

# Begin project code

# Push one Disk onto the Entry Conveyor
pneumatic_3.extend(CYLINDER1)
wait(1, SECONDS)
pneumatic_3.retract(CYLINDER1)
entry_conveyor_1.set_velocity(75, PERCENT)

# Move the Disk from the Entry Conveyor to the Transport Conveyor
entry_conveyor_1.spin(FORWARD)
wait(3, SECONDS)
entry_conveyor_1.stop()