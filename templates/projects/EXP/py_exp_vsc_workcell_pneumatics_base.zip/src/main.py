# ---------------------------------------------------------------------------- #
#                                                                              #
# 	Module:      {file}                                                        #
# 	Author:      {author}                                                      #
# 	Created:     {date}                                                        #
#	Description: {description}                                                 #
#                                                                              #
#   Configuration: EXP CTE Workcell Base + Pneumatics                          #
#                  6-Axis Robotic Arm in port 10                               #
#                  Signal Tower in port 6                                      #
#                  Transport Conveyor Motor in port 2                          #
#                  Optical Sensor in port 5                                    #
#                  Pneumatics in port 3                                        #
#                  Exit Conveyor Motor in port 4                               #
#                                                                              #
# ---------------------------------------------------------------------------- #

# Library imports
from vex import *
from cte import *

# Brain should be defined by default
brain = Brain()

# Robot configuration code
brain_inertial = Inertial()
entry_conveyor_1 = Motor(Ports.PORT1, False)
transport_conveyor_2 = Motor(Ports.PORT2, True)
pneumatic_3 = Pneumatic(Ports.PORT3)
exit_conveyor_4 = Motor(Ports.PORT4, False)
signal_tower_6 = SignalTower(Ports.PORT6)
arm_10 = Arm(Ports.PORT10)

def on_signal_tower_pressed():
    arm_10.set_control_stop(True)

def on_arm_control_stopped():
    # Visually indicate a controlled stop has occurred with the Signal Tower.
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.RED, SignalTower.BLINK)
    pneumatic_3.pump_off()
    entry_conveyor_1.stop()
    transport_conveyor_2.stop()
    exit_conveyor_4.stop()


def init_arm():
    # Initialize the 6-Axis Arm
    arm_10.initialize_arm()

    # Reset the Signal Tower lights
    signal_tower_6.set_color(SignalTower.ALL, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.ON)

    # register event handlers
    signal_tower_6.pressed(on_signal_tower_pressed)
    arm_10.control_stopped(on_arm_control_stopped)
    # add 15ms delay to make sure events are registered correctly.
    wait(15, MSEC)

# init arm
init_arm()

# Begin project code


