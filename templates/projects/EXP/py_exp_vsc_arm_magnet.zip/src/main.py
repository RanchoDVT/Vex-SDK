# ---------------------------------------------------------------------------- #
#                                                                              #
# 	Project:     Using the Magnet                                              #
# 	Module:      {file}                                                        #
# 	Author:      {author}                                                      #
# 	Created:     {date}                                                        #
#                                                                              #
#	Description: This example will show the Magnet picking up                  #
#                and releasing a Cube.                                         #
#                                                                              #
#	Configuration: Brain CTE 6-Axis Arm Base                                   #
#                  6-Axis Robotic Arm in port 10                               #
#                  Signal Tower in port 6                                      #
#                                                                              #
#   Setup: Place one Cube on Tile location 27.                                 #  
#                                                                              #
# ---------------------------------------------------------------------------- #

# Library imports
from vex import *
from cte import *

# Brain should be defined by default
brain = Brain()

# Robot configuration code
brain_inertial = Inertial()
arm_10 = Arm(Ports.PORT10)
signal_tower_6 = SignalTower(Ports.PORT6)


def on_signal_tower_pressed():
    arm_10.set_control_stop(True)

def on_arm_control_stopped():
    # Visually indicate a controlled stop has occurred with the Signal Tower.
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.RED, SignalTower.BLINK)


def init_arm():
    # Initialize the 6-Axis Arm
    arm_10.initialize_arm()

    # Reset the Signal Tower lights
    signal_tower_6.set_color(SignalTower.ALL, SignalTower.OFF)
    signal_tower_6.set_color(SignalTower.GREEN, SignalTower.ON)

    # register event handlers
    signal_tower_6.pressed(on_signal_tower_pressed)
    arm_10.control_stopped(on_arm_control_stopped)
    # add 15ms delay to make sure events are registered correctly.
    wait(15, MSEC)

# init arm
init_arm()

# Begin project code

# Use the Magnet to pick up the Cube on Tile location 27.
arm_10.set_end_effector_type(Arm.MAGNET)
arm_10.move_to(140, 55, 27)
arm_10.set_end_effector_magnet(True)

# Raise the 6-Axis Arm to verify the Disk has been picked up by the Magnet.
arm_10.move_to(140, 55, 175)

# Lower the 6-Axis Arm and release the Cube on Tile location 27.
arm_10.move_to(140, 55, 27)
arm_10.set_end_effector_magnet(False)

