# --------------------------------------------------------------------------------- #
#                                                                                   #
#    Project:           Split Arcade                                                #
#    Module:            main.py                                                     #
#    Author:            VEX                                                         #
#    Created:           Fri Aug 05 2022                                             #
#    Description:       The Left up/down Controller Axis (A) will drive             #
#                       the robot forward and backwards.                            #
#                       The Right left/right Controller Axis (C) will turn          #
#                       the robot left and right.                                   #
#                       The deadband variable prevents drift when                   #
#                       the Controller's joystick is released.                      #
#                                                                                   #
#    Configuration:     Left Motor in Port 1                                        #
#                       Right Motor in Port 6                                       #
#                       Controller                                                  #
#                                                                                   #
# --------------------------------------------------------------------------------- #

# Library imports
from vex import *

# Brain should be defined by default
brain=Brain()

# Robot configuration code
brain_inertial = Inertial()
left_motor = Motor(Ports.PORT1, False)
right_motor = Motor(Ports.PORT6, True)
controller = Controller()

# Begin project code
# Set the deadband variable
dead_band = 5

while True:
    # Get the positions of axis A and axis C
    axis_a_pos = controller.axisA.position()
    axis_c_pos = controller.axisC.position()

    if abs(axis_a_pos) + abs(axis_c_pos) > dead_band:
        left_motor.set_velocity((axis_a_pos + axis_c_pos), PERCENT)
        right_motor.set_velocity((axis_a_pos - axis_c_pos), PERCENT)
    else:
        left_motor.set_velocity(0, PERCENT)
        right_motor.set_velocity(0, PERCENT)
    left_motor.spin(FORWARD)
    right_motor.spin(FORWARD)

    wait(20, MSEC)
