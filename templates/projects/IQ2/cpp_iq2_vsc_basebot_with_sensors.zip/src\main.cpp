/*----------------------------------------------------------------------------------------*/
/*                                                                                        */                                                              
/*    Project:          Base Robot With Sensors                                           */
/*    Module:           main.cpp                                                          */
/*    Author:           VEX                                                               */
/*    Created:          Fri Aug 05 2022                                                   */
/*    Description:      Base IQ Gen 2 robot with controls and with sensors                */
/*                                                                                        */                                                              
/*    Configuration:    BaseBot with Sensors (Drivetrain 2-motor, Inertial)               */
/*                      Left Motor in Port 1                                              */
/*                      Right Motor in Port 6                                             */
/*                      TouchLED in Port 2                                                */
/*                      Optical Sensor in Port 3                                          */
/*                      Distance Sensor in Port 7                                         */
/*                      Bumper in Port 8                                                  */
/*                                                                                        */                                                              
/*----------------------------------------------------------------------------------------*/

// Include the IQ Library
#include "vex.h"

// Allows for easier use of the VEX Library
using namespace vex;

// Brain should be defined by default
brain Brain;

// Robot configuration code.
inertial BrainInertial = inertial();
motor LeftDriveSmart = motor(PORT1, 1, false);
motor RightDriveSmart = motor(PORT6, 1, true);

smartdrive Drivetrain = smartdrive(LeftDriveSmart, RightDriveSmart, BrainInertial, 200);

touchled TouchLED2 = touchled(PORT2);
optical Optical3 = optical(PORT3);
distance Distance7 = distance(PORT7);
bumper Bumper8 = bumper(PORT8);

void calibrateDrivetrain() {
  wait(200, msec);
  Brain.Screen.print("Calibrating");
  Brain.Screen.newLine();
  Brain.Screen.print("Inertial");
  BrainInertial.calibrate();
  while (BrainInertial.isCalibrating()) {
    wait(25, msec);
  }

  // Clears the screen and returns the cursor to row 1, column 1.
  Brain.Screen.clearScreen();
  Brain.Screen.setCursor(1, 1);
}

int main() {
  // Calibrates the Drivetrain Inertial
  calibrateDrivetrain();
  
  // Begin project code
  while(true){
    vexTaskSleep(100);
  }
}
