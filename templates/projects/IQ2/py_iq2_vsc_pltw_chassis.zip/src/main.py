# --------------------------------------------------------------------------------- #
#                                                                                   #
#    Project:          PLTW Template                                                #
#    Module:           main.py                                                      #
#    Author:           VEX                                                          #
#    Created:          Fri Aug 05 2022                                              #
#    Description:      An empty project for the Project Lead The Way chassis        #
#                                                                                   #
#    Configuration:    PLTW Chassis (Drivetrain 2-motor, No Gyro)                   #
#                      Color Sensor in Port 2                                       #
#                      TouchLED in Port 3                                           #
#                                                                                   #
# --------------------------------------------------------------------------------- #

# Library imports
from vex import *

# Brain should be defined by default
brain=Brain()

# Robot configuration code
brain_inertial = Inertial()
left_drive_smart = Motor(Ports.PORT1, 1, False)
right_drive_smart = Motor(Ports.PORT6, 1, True)
drivetrain = DriveTrain(left_drive_smart, right_drive_smart, 200, 173, 76, MM, 1)
color_2 = ColorSensor(Ports.PORT2)
touchled_3 = Touchled(Ports.PORT3)

# Begin project code
