/*----------------------------------------------------------------------------------------*/
/*                                                                                        */      
/*    Project:          PLTW Template                                                     */
/*    Module:           main.cpp                                                          */
/*    Author:           VEX                                                               */
/*    Created:          Fri Aug 05 2022                                                   */
/*    Description:      An empty project for the Project Lead The Way chassis             */
/*                                                                                        */      
/*    Configuration:    PLTW Chassis (Drivetrain 2-motor, No Gyro)                        */
/*                      Color Sensor in Port 2                                            */
/*                      TouchLED in Port 3                                                */
/*                                                                                        */      
/*----------------------------------------------------------------------------------------*/

// Include the IQ Library
#include "vex.h"

// Allows for easier use of the VEX Library
using namespace vex;

// Brain should be defined by default
brain Brain;

// Robot configuration code.
inertial BrainInertial = inertial();
motor LeftDriveSmart = motor(PORT1, 1, false);
motor RightDriveSmart = motor(PORT6, 1, true);
drivetrain Drivetrain = drivetrain(LeftDriveSmart, RightDriveSmart, 200, 173, 76, mm, 1);
colorsensor Color = colorsensor(PORT2);
touchled TouchLED3 = touchled(PORT3);

int main() {
  // Begin project code
    
}
