/*--------------------------------------------------------------------------------------------*/
/*                                                                                            */      
/*    Project:          Controlling Fling                                                     */
/*    Module:           main.cpp                                                              */
/*    Author:           VEX                                                                   */
/*    Created:          Fri Aug 05 2022                                                       */
/*    Description:      This program shows how to control Fling's motors with the             */
/*                      controller events and the drivetrain with the configured controller.  */
/*                      The Left up/down controller buttons will control the Intake Motor     */
/*                      The Right up/down controller buttons will control the Catapult Motor  */
/*                      The Joysticks are configured for Tank control                         */
/*                                                                                            */      
/*    Configuration:    VIQC 2021 Fling (Drivetrain 2-motor, Reversed + Controller)           */
/*                      Drivetrain in Ports 1 and 3                                           */
/*                      Bumper in Port 5                                                      */
/*                      Catapult Motor in Port 4                                              */
/*                      Intake Motor in Port 2                                                */
/*                                                                                            */      
/*--------------------------------------------------------------------------------------------*/
// Include the IQ Library
#include "vex.h"
  
// Allows for easier use of the VEX Library
using namespace vex;

// Brain should be defined by default
brain Brain;

// Robot configuration code.
inertial BrainInertial = inertial();
motor LeftDriveSmart = motor(PORT1, 1, true);
motor RightDriveSmart = motor(PORT3, 1, false);
drivetrain Drivetrain = drivetrain(LeftDriveSmart, RightDriveSmart, 200, 260, 76, mm, 1);
bumper Bumper = bumper(PORT5);
motor CatapultMotor = motor(PORT4, true);
motor IntakeMotor = motor(PORT2, true);
controller Controller = controller();

// define a task that will handle monitoring inputs from Controller
int rc_auto_loop_function_Controller() {
  // process the controller input every 20 milliseconds
  // update the motors based on the input values
  while(true) {
    // calculate the drivetrain motor velocities from the controller joystick axies
    // left = AxisA
    // right = AxisD
    int drivetrainLeftSideSpeed = Controller.AxisA.position();
    int drivetrainRightSideSpeed = Controller.AxisD.position();

    // threshold the variable channels so the drive does not
    // move if the joystick axis does not return exactly to 0
    const int deadband = 15;
    if(abs(drivetrainLeftSideSpeed) < deadband) {
      drivetrainLeftSideSpeed = 0;
    }

    if(abs(drivetrainRightSideSpeed) < deadband) {
      drivetrainRightSideSpeed = 0;
    }

    // update motor velocities
    LeftDriveSmart.spin(forward, drivetrainLeftSideSpeed, percent);
    RightDriveSmart.spin(forward, drivetrainRightSideSpeed, percent);

    // wait before repeating the process
    wait(25, msec);
  }
  return 0;
}

task rc_auto_loop_task_Controller(rc_auto_loop_function_Controller);

// Callback function when Controller ButtonRUp is pressed
void onButtonRUpPress() {
  CatapultMotor.spin(reverse);

  while (Controller.ButtonRUp.pressing()) {
    // Wait until ButtonRUp is released
    wait(20, msec);
  }

  CatapultMotor.stop();
}

// Callback function when Controller ButtonLUp is pressed
void onButtonLUpPress() {
  IntakeMotor.spin(reverse);

  while (Controller.ButtonLUp.pressing()) {
    // Wait until ButtonLUp is released
    wait(20, msec);
  }

  IntakeMotor.stop();
}

// Callback function when Controller ButtonRDown is pressed
void onButtonRDownPress() {
  CatapultMotor.spin(forward);

  while (Controller.ButtonRDown.pressing()) {
    // Wait until ButtonRDown is released
    wait(20, msec);
  }

  CatapultMotor.stop();
}

// Callback function when Controller ButtonLDown is pressed
void onButtonLDownPress() {
  IntakeMotor.spin(forward);

  while (Controller.ButtonLDown.pressing()) {
    // Wait until ButtonLDown is released
    wait(20, msec);
  }

  IntakeMotor.stop();
}


int main() {
  // Register event handlers and pass callback functions
  Controller.ButtonRUp.pressed(onButtonRUpPress);
  Controller.ButtonLUp.pressed(onButtonLUpPress);
  Controller.ButtonRDown.pressed(onButtonRDownPress);
  Controller.ButtonLDown.pressed(onButtonLDownPress);

  // Set default motor stopping behavior
  CatapultMotor.setStopping(hold);
  IntakeMotor.setStopping(hold);
}
