# --------------------------------------------------------------------------------- #
#                                                                                   #
#    Project:            Controlling Fling                                           #
#    Module:            main.py                                                     #
#    Author:            VEX                                                         #
#    Created:           Fri Aug 05 2022                                             #
#    Description:       This program shows how to control Fling's motors with       #
#                       the controller events and the drivetrain with               #
#                       the configured controller.                                  #
#                       The Left up/down controller buttons will control            #
#                       the Intake Motor                                            #
#                       The Right up/down controller buttons will control           #
#                       the Catapult Motor                                          #
#                       The Joysticks are configured for Tank control               #
#                                                                                   #
#    Configuration:     VIQC 2021 Fling (Drivetrain 2-motor, Reversed)              #
#                       Drivetrain in Ports 1 and 3                                 #
#                       Bumper in Port 5                                            #
#                       Catapult Motor in Port 4                                    #
#                       Intake Motor in Port 2                                      #
#                       Controller                                                  #
#                                                                                   #
# --------------------------------------------------------------------------------- #

# Library imports
from vex import *

# Brain should be defined by default
brain=Brain()

# Robot configuration code
brain_inertial = Inertial()
left_drive_smart = Motor(Ports.PORT1, 1, True)
right_drive_smart = Motor(Ports.PORT3, 1, False)
drivetrain = DriveTrain(left_drive_smart, right_drive_smart, 200, 260, 76, MM, 1)
bumper_sensor = Bumper(Ports.PORT5)
catapult_motor = Motor(Ports.PORT4, True)
intake_motor = Motor(Ports.PORT2, True)
controller = Controller()

# define a task that will handle monitoring inputs from controller
def rc_auto_loop_function_controller():
    # process the controller input every 25 milliseconds
    # update the motors based on the input values
    while True:
        # calculate the drivetrain motor velocities from the controller joystick axies
        # left = axisA
        # right = axisD
        drivetrain_left_side_speed = controller.axisA.position()
        drivetrain_right_side_speed = controller.axisD.position()
        
        # threshold the variable channels so the drive does not
        # move if the joystick axis does not return exactly to 0
        deadband = 15
        if abs(drivetrain_left_side_speed) < deadband:
            drivetrain_left_side_speed = 0
        if abs(drivetrain_right_side_speed) < deadband:
            drivetrain_right_side_speed = 0

        # Now send all drive values to motors
        left_drive_smart.spin(FORWARD, drivetrain_left_side_speed, PERCENT)
        right_drive_smart.spin(FORWARD, drivetrain_right_side_speed, PERCENT)


        # wait before repeating the process
        wait(25, MSEC)

rc_auto_loop_thread_controller = Thread(rc_auto_loop_function_controller)

# Begin project code
# Callback function when Controller buttonLDown is pressed
def on_L_down_pressed():
    intake_motor.spin(FORWARD)

    while controller.buttonLDown.pressing():
        # Wait until buttonLDown is released
        wait(20, MSEC)

    intake_motor.stop()


# Callback function when Controller buttonLUp is pressed
def on_L_up_pressed():
    intake_motor.spin(REVERSE)

    while controller.buttonLUp.pressing():
        # Wait until buttonLUp is released
        wait(20, MSEC)

    intake_motor.stop()


# Callback function when Controller buttonRDown is pressed
def on_R_down_pressed():
    catapult_motor.spin(FORWARD)

    while controller.buttonRDown.pressing():
        # Wait until buttonRDown is released
        wait(20, MSEC)

    catapult_motor.stop()


# Callback function when Controller buttonRUp is pressed
def on_R_up_pressed():
    catapult_motor.spin(REVERSE)

    while controller.buttonRUp.pressing():
        # Wait until buttonRUp is released
        wait(20, MSEC)

    catapult_motor.stop()


# Register event handlers and pass callback functions
controller.buttonLUp.pressed(on_L_up_pressed)
controller.buttonRDown.pressed(on_R_down_pressed)
controller.buttonRUp.pressed(on_R_up_pressed)
controller.buttonLDown.pressed(on_L_down_pressed)

# Set default motor stopping behavior
catapult_motor.set_stopping(HOLD)
catapult_motor.set_stopping(HOLD)
