/*----------------------------------------------------------------------------------------*/
/*                                                                                        */    
/*    Project:          Using Threads                                                     */
/*    Module:           main.cpp                                                          */
/*    Author:           VEX                                                               */
/*    Created:          Fri Aug 05 2022                                                   */
/*    Description:      This example will show how to run multiple threads (tasks)        */
/*                      in a project at the same time                                     */
/*                                                                                        */    
/*    Configuration:    None                                                              */
/*                                                                                        */    
/*----------------------------------------------------------------------------------------*/

// Include the IQ Library
#include "vex.h"

// Allows for easier use of the VEX Library
using namespace vex;

// Brain should be defined by default
brain Brain;

// Create a function that will be used as a thread.
void myThreadCallback1() {
  int threadLoopCount = 0;

  // Change the font size to fit on the IQ (2nd generation) Brain's screen
  Brain.Screen.setFont(mono12);

  while(true) {
    Brain.Screen.setCursor(2, 1);
    Brain.Screen.print("250ms Loop: %d", threadLoopCount);
    threadLoopCount += 1;
    wait(0.25, seconds);
  }
}

void myThreadCallback2() {
  int threadLoopCount = 0;

  // Change the font size to fit on the IQ (2nd generation) Brain's screen
  Brain.Screen.setFont(mono12);

  while(true) {
    Brain.Screen.setCursor(3, 1);
    Brain.Screen.print("500ms Loop: %d", threadLoopCount);
    threadLoopCount += 1;
    wait(0.5, seconds);
  }
}


int main() {
  // Creating instances of threads will start the threads immediately.
  thread myThread1 = thread(myThreadCallback1);
  thread myThread2 = thread(myThreadCallback2);

  // Print from the main thread to show that it is running at the same time as other threads.
  int mainThreadCount = 0;

  // Change the font size to fit on the IQ (2nd generation) Brain's screen
  Brain.Screen.setFont(mono12);
  
  while(true) {
    Brain.Screen.setCursor(1, 1);
    Brain.Screen.print("100ms Loop: %d", mainThreadCount);
    
    mainThreadCount += 1;
    wait(0.1, seconds);
  }
}
