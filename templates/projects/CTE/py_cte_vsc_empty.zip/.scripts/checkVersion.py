import sys

def simpleVersionStr(major,minor,micro):
    return "%s.%s.%s" % (major,minor,micro)


def __main__():
    MAJOR=3
    MINOR=7
    MICRO=0
    version_info = sys.version_info

    minPythonVersion = simpleVersionStr(MAJOR,MINOR,MICRO)
    systemPythonVersion = simpleVersionStr(version_info[0],version_info[1],version_info[2])


    if version_info[0] >= MAJOR and version_info[1] >= MINOR and version_info[2] >= MICRO:
        print("Python Version: %s" % (systemPythonVersion))
    else:
        print("Invalid Python Version: %s, Expected: %s" % (systemPythonVersion,minPythonVersion))
        sys.exit(-1)


__main__()