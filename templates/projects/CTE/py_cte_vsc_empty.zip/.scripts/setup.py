import venv
import sys
import pathlib
import subprocess
import platform

def createVenv(path) -> pathlib.Path:

    venv_path = pathlib.Path(path,".venv")

    if not venv_path.exists():
        print("Creating venv at: ",path)
        venv.create(env_dir=venv_path,with_pip=True)  
    else:
        print("venv at: ",path)
  

    return venv_path

def installRequirements(cwdPath:pathlib.Path,envPath:pathlib.Path,package:str):
    pythonPath = ""
    if platform.platform().find("Windows") != -1:
        pythonPath = envPath.joinpath("Scripts","python")

    else:
        pythonPath = envPath.joinpath("bin","python")
    
    subprocess.check_call(cwd=cwdPath,args=[pythonPath, "-m", "pip", "install", "-r", package])


def __main__():
    print("Running Setup")

    # Create Path
    workspace_path = pathlib.Path(sys.argv[1])
    # Create Virtual ENV
    venv_path = createVenv(workspace_path)

    # Install Requirements.txt
    installRequirements(workspace_path,venv_path,"requirements.txt")

    print("Finished")

__main__()

