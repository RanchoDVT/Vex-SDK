# ---------------------------------------------------------------------------- #
#                                                                              #
# 	Module:       {file}                                                       #
# 	Author:       {author}                                                     #
# 	Created:      {date}                                                       #
# 	Description:  CTE Arm project                                              #
#                                                                              #
# ---------------------------------------------------------------------------- #

# Library imports
from cte import *
import time 

# Create and instance of the Arm class
# If the arm is not connected via USB, the constructor will throw an exception
arm = Arm()
signal_tower = arm.signal_tower

# setup observers for signal tower button press and release
signal_tower.pressed(lambda: print("Button Pressed"))
signal_tower.released(lambda: print("Button Released"))

# setup observer for command complete
arm.command_completed(lambda: print("Command Complete"))

# Put the arm in a known start position
arm.initialize_arm()

while True:
        # Display the current arm position
        print("Arm Position: ", arm.get_x(), " : ", arm.get_y(), " : ", arm.get_z())
        time.sleep(0.5)